package com.example.springboot.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data   // 自动生成getter和setter方法
@AllArgsConstructor // 自动生成带所有参数的构造方法
@NoArgsConstructor  // 自动生成无参数的构造方法
public class UserInfo {

    //用户id
    private Integer userinfoId;

    //用户名
    private String userinfoName;

    //密码
    private String passWord;

    //手机号码
    private String tel;
}
