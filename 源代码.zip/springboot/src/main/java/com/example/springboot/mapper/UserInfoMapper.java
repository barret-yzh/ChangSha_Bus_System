package com.example.springboot.mapper;

import com.example.springboot.entity.NumBySexInfo;
import com.example.springboot.entity.NumInfo;
import com.example.springboot.entity.UserInfo;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface UserInfoMapper {

    // 登录接口定义
    @Select("select * from userinfo where userinfoName = #{username} and passWord = #{password}")
    UserInfo login(String username, String password);

    @Insert("insert into userinfo (userinfoName, passWord, tel) values (#{userinfoName}, #{passWord}, #{tel})")
    Integer add(UserInfo userInfo);

    @Update("update userinfo set userinfoName = #{userinfoName}, passWord = #{passWord}, tel = #{tel} where userinfoId = #{userinfoId}")
    Integer modify(UserInfo userInfo);

    @Delete("delete from userinfo where userinfoId = #{userinfoId}")
    Integer remove(Integer userinfoId);

    // 男女数量接口定义
    @Select("SELECT employeesex sexName, COUNT(*) sexNum FROM employee GROUP BY employeesex")
    List<NumBySexInfo> findNumBySex();

    // 注册接口定义
    @Insert("insert into userinfo (userinfoName, passWord, tel) values (#{userinfoName}, #{passWord}, #{tel})")
    Integer register(UserInfo userInfo);

    //修改密码接口定义
    @Update("update userinfo set passWord = #{password} where tel = #{tel}")
    Integer editPassword (@Param("password")String password,@Param("tel") String tel);

}
