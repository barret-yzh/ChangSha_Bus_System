package com.example.springboot.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data   // 自动生成getter和setter方法
@AllArgsConstructor // 自动生成带所有参数的构造方法
@NoArgsConstructor  // 自动生成无参数的构造方法
public class NumInfo {

    // 电子站牌数量
    private Integer electronicNum;

    // 站牌、站点数量
    private Integer siteNum;

    // 站场数量
    private Integer stationyardNum;

    // 公交数量
    private Integer busNum;

    // 路线数量
    private Integer lineNum;

    // 总里程数
    private Integer lineCountNum;

}
