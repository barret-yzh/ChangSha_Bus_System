package com.example.springboot.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

//表示这是一个控制类@Controller(控制类)+@ResponseBody(返回json数据格式)
@RestController
//访问路径，相当于路由
@RequestMapping("/test")
public class TestController {
    @RequestMapping("/test")
    public String test(){
        return "Hello SpringBoot!";
    }
}
