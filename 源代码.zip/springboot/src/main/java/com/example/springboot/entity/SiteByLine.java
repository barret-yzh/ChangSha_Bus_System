package com.example.springboot.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data   // 自动生成getter和setter方法
@AllArgsConstructor // 自动生成带所有参数的构造方法
@NoArgsConstructor  // 自动生成无参数的构造方法
public class SiteByLine {

    private Integer lineId;	//线路id

    private String siteName;//详细站点名称

    private String siteId;//站点id

}

