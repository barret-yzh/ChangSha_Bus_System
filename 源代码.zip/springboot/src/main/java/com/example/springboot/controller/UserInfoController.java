package com.example.springboot.controller;

import com.example.springboot.entity.NumBySexInfo;
import com.example.springboot.entity.UserInfo;
import com.example.springboot.service.UserInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@CrossOrigin    // 允许跨域访问
public class UserInfoController {

    // 注入service层
    @Autowired
    UserInfoService userInfoService;

    @RequestMapping(value = "/login", method = RequestMethod.GET)
    public ResponseEntity<UserInfo> login(String username, String password) {

        UserInfo userInfo = userInfoService.login(username, password);

        return new ResponseEntity<>(userInfo, HttpStatus.OK);

    }

    // 男女数量接口
    @RequestMapping(value = "/findNumBySex", method = RequestMethod.GET)
    public ResponseEntity<List<NumBySexInfo>> findNumBySex() {

        List<NumBySexInfo> list = userInfoService.findNumBySex();

        return new ResponseEntity<>(list, HttpStatus.OK);

    }

    //注册接口
    @RequestMapping(value = "/register",method = RequestMethod.GET)
    public ResponseEntity<Integer> register(String username, String password, String tel){
        Integer count = userInfoService.register(username, password,tel);
        System.out.println(count);
        System.out.println(username+" "+password+" "+tel);
        return new ResponseEntity<>(count, HttpStatus.OK);

    }

    //修改密码接口
    @RequestMapping(value = "/editPassword",method = RequestMethod.GET)
    public ResponseEntity<Integer> editPassword(String password, String tel) {
        System.out.println(password+" "+tel);

        Integer count = userInfoService.editPassword(password, tel);

        return new ResponseEntity<>(count, HttpStatus.OK);

    }

}
