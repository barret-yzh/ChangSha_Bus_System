package com.example.springboot.controller;

import com.example.springboot.entity.*;
import com.example.springboot.service.BusService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@CrossOrigin    // 允许跨域访问
public class BusController {

    @Autowired
    BusService busService;

    // 企业公交车数量接口
    @RequestMapping(value = "/findBusNumByBusiness", method = RequestMethod.GET)
    public ResponseEntity<List<Bus>> findBusNumByBusiness() {

        List<Bus> list = busService.findBusNumByBusiness();

        return new ResponseEntity<>(list, HttpStatus.OK);

    }

    // 数量接口
    @RequestMapping(value = "/findNum", method = RequestMethod.GET)
    public ResponseEntity<NumInfo> findNum() {

        NumInfo numInfo = busService.findNum();

        return new ResponseEntity<>(numInfo, HttpStatus.OK);

    }

    // 线路总里程和配车数接口
    @RequestMapping(value = "/findLineCountAndBusNumByBusiness", method = RequestMethod.GET)
    public ResponseEntity<List<Business>> findLineCountAndBusNumByBusinessId() {

        List<Business> list = busService.findLineCountAndBusNumByBusinessId();

        return new ResponseEntity<>(list, HttpStatus.OK);

    }

    // 搜索接口
    @RequestMapping(value = "/findLineByLineName", method = RequestMethod.GET)
    public ResponseEntity<List<LineInfo>> findLineByLineName(String lineName) {

        List<LineInfo> list = busService.findLineByLineName(lineName);

        return new ResponseEntity<>(list, HttpStatus.OK);

    }

    // 站点点击接口
    @RequestMapping(value = "/findLineNameByStileName", method = RequestMethod.GET)
    public ResponseEntity<List<LineInfo>> findLineNameByStileName(String siteName) {

        List<LineInfo> list = busService.findLineNameByStileName(siteName);

        return new ResponseEntity<>(list, HttpStatus.OK);

    }

    //线路详情接口
    @RequestMapping(value = "/findLineParticulars", method = RequestMethod.GET)
    public ResponseEntity<List<SiteByLine>> lineParticulars(Integer lineId) {

        List<SiteByLine> list = busService.lineParticulars(lineId);

        return new ResponseEntity<>(list, HttpStatus.OK);

    }

}
