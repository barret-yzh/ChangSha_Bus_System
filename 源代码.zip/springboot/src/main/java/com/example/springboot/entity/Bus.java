package com.example.springboot.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data   // 自动生成getter和setter方法
@AllArgsConstructor // 自动生成带所有参数的构造方法
@NoArgsConstructor  // 自动生成无参数的构造方法
public class Bus {

    // 企业ID
    private Integer businessId;

    // 企业名
    private String businessName;

    // 公交数量
    private Integer busNum;

    // 所属企业id
    private Integer busSinessId;

}
