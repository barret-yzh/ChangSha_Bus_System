package com.example.springboot.mapper;

import com.example.springboot.entity.*;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface BusMapper {

    // 企业公交车数量接口定义
    @Select("SELECT b.*, bustab.busNum from business b INNER JOIN (select busSinessId, count(*) busNum from bus " +
            "GROUP BY busSinessId) bustab ON b.businessId =  bustab.busSinessId")
    List<Bus> findBusNumByBusiness();

    // 线路总里程和配车数接口定义
    @Select("SELECT b.businessId, b.businessName, l.CountNum, btab.busNum from business b INNER JOIN " +
            "(SELECT businessId, sum(lineCount) CountNum from line GROUP BY businessId) l on b.businessId " +
            "= l.businessId INNER JOIN (SELECT busSinessId, count(*) busNum from bus GROUP BY busSinessId) btab " +
            "ON b.businessId = btab.busSinessId")
    List<Business> findLineCountAndBusNumByBusinessId();

    // 数量接口定义
    @Select("SELECT * FROM\n" +
            "(SELECT  count(distinct siteName) electronicNum FROM  sitetable WHERE IsElectronic='1') electronicTab,\n" +
            "\n" +
            "(SELECT  count(distinct siteName)siteNum from sitetable ) siteTab,\n" +
            "\n" +
            "(SELECT  count(distinct siteName) stationyardNum FROM  sitetable WHERE isStationyard='1') stationyardTab,\n" +
            "\n" +
            "(SELECT count(busNumber) busNum FROM bus) busTab,\n" +
            "\n" +
            "(SELECT  count(lineName) lineNum FROM line) lineTab,\n" +
            "\n" +
            "(SELECT  sum(lineCount) lineCountNum FROM line) lineCountTab\n")
    NumInfo findNum ();

    // 搜索接口定义
    @Select("SELECT l.lineId,l.lineName,l.lineWinter,l.lineSummer,l.linePrice,l.businessId,l.lineStartId,l.lineEndId" +
            ",b.businessName,s.siteName startsiteName,si.siteName endsiteName FROM\n" +
            "\tline l\n" +
            "\tINNER JOIN business b ON l.businessId = b.businessId\n" +
            "\tINNER JOIN sitetable s ON l.lineStartId = s.siteId\n" +
            "\tINNER JOIN sitetable si ON l.lineEndId = si.siteId \n" +
            "WHERE\n" +
            "\tl.lineName LIKE concat('%', #{lineName}, '%')")
    List<LineInfo> findLineByLineName(String lineName);

    // 站点点击接口定义
    @Select("SELECT DISTINCT l1.lineId, l1.lineName, l1.lineWinter, l1.lineSummer, l1.lineStartId, l1.lineEndId," +
            " l1.linePrice, s2.siteName endsiteName, s3.siteName startsiteName, b.businessName FROM sitetable s1 " +
            "INNER JOIN sitebyline sbl1 on sbl1.siteId = s1.siteId INNER JOIN line l1 on l1.lineId = sbl1.lineId " +
            "INNER JOIN sitetable s2 on l1.lineEndId = s2.siteId INNER JOIN sitetable s3 ON l1.lineStartId = s3.siteId " +
            "INNER JOIN business b ON l1.businessId = b.businessId WHERE s1.siteName = #{siteName}")
    List<LineInfo> findLineNameByStileName(String siteName);

    //线路详情接口定义
    @Select("select s.siteId,s.siteName,stab.lineId, stab.siteOrder from sitetable s \n" +
            "INNER JOIN\n" +
            "(SELECT lineId,siteId,siteOrder from sitebyline where lineId = #{lineId}) stab\n" +
            "ON\n" +
            "s.siteId = stab.siteId\n" +
            "ORDER BY stab.siteOrder asc")
    List<SiteByLine> lineParticulars(Integer lineId);

}
