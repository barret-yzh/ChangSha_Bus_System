package com.example.springboot.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data   // 自动生成getter和setter方法
@AllArgsConstructor // 自动生成带所有参数的构造方法
@NoArgsConstructor  // 自动生成无参数的构造方法
public class LineInfo {

    // 线路id
    private Integer lineId;

    // 路线名称，不能为空
    private String lineName;

    // 企业名
    private String businessName;

    // 冬季运营时间
    private String lineWinter;

    // 夏季运营时间
    private String lineSummer;

    // 起点站名称
    private String startsiteName;

    // 票价
    private Integer linePrice;

    // 终点站名
    private String endsiteName;

    // 起点站id
    private Integer lineStartId;

    // 终点站id
    private Integer lineEndId;

}
