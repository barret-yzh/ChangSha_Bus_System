package com.example.springboot.service;

import com.example.springboot.entity.NumBySexInfo;
import com.example.springboot.entity.NumInfo;
import com.example.springboot.entity.UserInfo;
import com.example.springboot.mapper.UserInfoMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserInfoService {

    @Autowired
    UserInfoMapper userInfoMapper;

    // 登录
    public UserInfo login (String username, String password) {

        return userInfoMapper.login(username, password);

    }

    // 男女数量
    public List<NumBySexInfo> findNumBySex() {

        return userInfoMapper.findNumBySex();

    }

    // 注册
    public Integer register(String username,String password,String tel){
        UserInfo userInfo=new UserInfo();
        userInfo.setUserinfoName(username);
        userInfo.setPassWord(password);
        userInfo.setTel(tel);
        return userInfoMapper.register(userInfo);
    }

    // 修改密码
    public Integer editPassword(String password,String tel){
        return userInfoMapper.editPassword(password,tel);

    }

}
