package com.example.springboot.service;

import com.example.springboot.entity.*;
import com.example.springboot.mapper.BusMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BusService {

    @Autowired
    BusMapper busMapper;

    // 企业公交车数量接口
    public List<Bus> findBusNumByBusiness() {

        return busMapper.findBusNumByBusiness();

    }

    // 线路总里程和配车数接口
    public List<Business> findLineCountAndBusNumByBusinessId() {

        return busMapper.findLineCountAndBusNumByBusinessId();

    }

    // 数量接口
    public NumInfo findNum() {

        return busMapper.findNum();

    }

    // 搜索接口
    public List<LineInfo> findLineByLineName(String lineName) {

        return busMapper.findLineByLineName(lineName);

    }

    // 站点点击接口
    public List<LineInfo> findLineNameByStileName(String siteName) {

        return busMapper.findLineNameByStileName(siteName);

    }

    //线路详情
    public List<SiteByLine> lineParticulars(Integer lineId){
        return busMapper.lineParticulars(lineId);
    }

}
