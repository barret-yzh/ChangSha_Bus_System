package com.example.springboot;

import com.example.springboot.entity.LineInfo;
import com.example.springboot.entity.NumBySexInfo;
import com.example.springboot.entity.UserInfo;
import com.example.springboot.mapper.BusMapper;
import com.example.springboot.mapper.UserInfoMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
public class SpringbootApplicationTests {

    @Autowired  // 自动注入
    UserInfoMapper userInfoMapper;

    @Autowired
    BusMapper busMapper;

    @Test
    public void testLogin() {

        UserInfo u = userInfoMapper.login("444", "444");
        System.out.println(u.toString());

    }

    @Test
    public void testAdd() {

        UserInfo u = new UserInfo();
        u.setUserinfoName("adminTest");
        u.setPassWord("admin");
        u.setTel("188888888");
        Integer result = userInfoMapper.add(u);
        System.out.println(result);

    }

    @Test
    public void testModify() {

        UserInfo u = new UserInfo();
        u.setUserinfoId(24);
        u.setUserinfoName("adminTest");
        u.setPassWord("123");
        u.setTel("110");
        Integer result = userInfoMapper.modify(u);
        System.out.println(result);

    }

    @Test
    public void testRemove() {
        Integer result = userInfoMapper.remove(24);
        System.out.println(result);
    }

    @Test
    public void testFindNumBySex() {
        List<NumBySexInfo> list = userInfoMapper.findNumBySex();
        System.out.println(list);
    }

    @Test
    public void testsql() {

        List<LineInfo> list = busMapper.findLineByLineName("%长沙%");
        System.out.println(list);

    }

}
