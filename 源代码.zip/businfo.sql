/*
 Navicat Premium Data Transfer

 Source Server         : 长沙市公交系统
 Source Server Type    : MySQL
 Source Server Version : 50723
 Source Host           : localhost:3306
 Source Schema         : businfo

 Target Server Type    : MySQL
 Target Server Version : 50723
 File Encoding         : 65001

 Date: 08/07/2022 10:30:36
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for bus
-- ----------------------------
DROP TABLE IF EXISTS `bus`;
CREATE TABLE `bus`  (
  `busId` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键，自增',
  `busNumber` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '车牌号',
  `busByLineId` int(11) NOT NULL COMMENT '汽车所属线路id',
  `busSinessId` int(11) NOT NULL COMMENT '所属企业id',
  PRIMARY KEY (`busId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 35 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of bus
-- ----------------------------
INSERT INTO `bus` VALUES (1, '湘AJI210', 1, 2);
INSERT INTO `bus` VALUES (2, '湘A51367', 2, 1);
INSERT INTO `bus` VALUES (3, '湘A332F4', 3, 1);
INSERT INTO `bus` VALUES (4, '湘AUI76G', 4, 3);
INSERT INTO `bus` VALUES (5, '湘AYJU67', 5, 2);
INSERT INTO `bus` VALUES (6, '湘A56768', 6, 3);
INSERT INTO `bus` VALUES (7, '湘A01040	', 7, 2);
INSERT INTO `bus` VALUES (8, '湘A11004', 8, 1);
INSERT INTO `bus` VALUES (9, '湘AUU67H', 9, 2);
INSERT INTO `bus` VALUES (10, '湘A4G463', 10, 2);
INSERT INTO `bus` VALUES (11, '湘ASDFD3', 11, 3);
INSERT INTO `bus` VALUES (12, '湘A1044F', 12, 1);
INSERT INTO `bus` VALUES (13, '湘A56J67', 13, 1);
INSERT INTO `bus` VALUES (14, '湘A04223', 14, 1);
INSERT INTO `bus` VALUES (15, '湘AYU7GF', 15, 2);
INSERT INTO `bus` VALUES (16, '湘A66701', 16, 3);
INSERT INTO `bus` VALUES (17, '湘A4G453', 17, 1);
INSERT INTO `bus` VALUES (18, '湘AG56HS', 18, 1);
INSERT INTO `bus` VALUES (19, '湘ARY54F	', 19, 2);
INSERT INTO `bus` VALUES (20, '湘ASDFV3', 1, 3);
INSERT INTO `bus` VALUES (21, '湘A222S1', 2, 1);
INSERT INTO `bus` VALUES (22, '湘A120SK', 3, 1);
INSERT INTO `bus` VALUES (23, '湘A5SAD1', 4, 3);
INSERT INTO `bus` VALUES (24, '湘A5SAD1', 5, 2);
INSERT INTO `bus` VALUES (25, '湘AJI211', 1, 2);
INSERT INTO `bus` VALUES (26, '湘AJI212', 1, 2);
INSERT INTO `bus` VALUES (27, '湘AJI213', 2, 3);
INSERT INTO `bus` VALUES (28, '湘AJI214', 2, 3);
INSERT INTO `bus` VALUES (29, 'test1', 1, 1);
INSERT INTO `bus` VALUES (30, 'test2', 2, 2);
INSERT INTO `bus` VALUES (31, 'test3', 1, 1);
INSERT INTO `bus` VALUES (32, 'test4', 2, 2);
INSERT INTO `bus` VALUES (33, 'test3', 1, 1);
INSERT INTO `bus` VALUES (34, 'test4', 2, 2);

-- ----------------------------
-- Table structure for busimg
-- ----------------------------
DROP TABLE IF EXISTS `busimg`;
CREATE TABLE `busimg`  (
  `busid` int(11) NOT NULL AUTO_INCREMENT,
  `busnumber` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `busimg` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`busid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 19 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of busimg
-- ----------------------------
INSERT INTO `busimg` VALUES (1, '湘A235FH', 'D:\\photoTest\\50d6c0a7-1cc4-4955-bfdb-89e60fe18e03.jpg');
INSERT INTO `busimg` VALUES (14, '湘A234FH', 'D:\\photoTest\\1.jpg');
INSERT INTO `busimg` VALUES (15, '湘A236FH', 'D:\\photoTest\\2.jpg');
INSERT INTO `busimg` VALUES (16, '湘A237FH', 'D:\\photoTest\\3.jpg');
INSERT INTO `busimg` VALUES (17, '湘A238FH', 'D:\\photoTest\\4.jpg');
INSERT INTO `busimg` VALUES (18, '湘A239FH', 'D:\\photoTest\\5.jpg');

-- ----------------------------
-- Table structure for business
-- ----------------------------
DROP TABLE IF EXISTS `business`;
CREATE TABLE `business`  (
  `businessId` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键,自增',
  `businessName` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '企业名',
  PRIMARY KEY (`businessId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of business
-- ----------------------------
INSERT INTO `business` VALUES (1, '龙骧公交公司');
INSERT INTO `business` VALUES (2, '宝骏公交公司');
INSERT INTO `business` VALUES (3, '湖南公交公司');

-- ----------------------------
-- Table structure for employee
-- ----------------------------
DROP TABLE IF EXISTS `employee`;
CREATE TABLE `employee`  (
  `employeeId` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键,自增',
  `employeeSex` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '员工性别',
  `businessId` int(11) NOT NULL COMMENT '所属企业',
  PRIMARY KEY (`employeeId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 19 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of employee
-- ----------------------------
INSERT INTO `employee` VALUES (1, '男', 1);
INSERT INTO `employee` VALUES (2, '女', 1);
INSERT INTO `employee` VALUES (3, '男', 1);
INSERT INTO `employee` VALUES (4, '女', 1);
INSERT INTO `employee` VALUES (5, '男', 1);
INSERT INTO `employee` VALUES (6, '男', 1);
INSERT INTO `employee` VALUES (7, '女', 2);
INSERT INTO `employee` VALUES (8, '男', 2);
INSERT INTO `employee` VALUES (9, '男', 2);
INSERT INTO `employee` VALUES (10, '男', 2);
INSERT INTO `employee` VALUES (11, '女', 2);
INSERT INTO `employee` VALUES (12, '男', 2);
INSERT INTO `employee` VALUES (13, '男', 3);
INSERT INTO `employee` VALUES (14, '女', 3);
INSERT INTO `employee` VALUES (15, '男', 3);
INSERT INTO `employee` VALUES (16, '男', 3);
INSERT INTO `employee` VALUES (17, '女', 3);
INSERT INTO `employee` VALUES (18, '男', 3);

-- ----------------------------
-- Table structure for line
-- ----------------------------
DROP TABLE IF EXISTS `line`;
CREATE TABLE `line`  (
  `lineId` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键，自增',
  `lineName` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '线路名',
  `lineCount` int(30) NOT NULL COMMENT '线路里程数',
  `lineStartId` int(11) NOT NULL COMMENT '线路起点站点id',
  `lineEndId` int(11) NOT NULL COMMENT '线路终点站点id',
  `linePrice` int(11) NOT NULL COMMENT '票价',
  `lineSummer` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '运营时间(夏)',
  `lineWinter` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '运营时间(冬)',
  `businessId` int(11) NOT NULL COMMENT '所属企业',
  PRIMARY KEY (`lineId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 21 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of line
-- ----------------------------
INSERT INTO `line` VALUES (1, '1路公交车', 20, 1, 20, 2, '6:00--22:00', '6:30--22:00', 1);
INSERT INTO `line` VALUES (2, '长沙2路公交车', 36, 21, 56, 2, '6:00--22:00', '6:30--22:00', 2);
INSERT INTO `line` VALUES (3, '长沙4路公交线路', 22, 101, 122, 2, '6:00--22:00', '6:30--22:00', 1);
INSERT INTO `line` VALUES (4, '长沙6路公交线路', 28, 123, 154, 2, '6:00--22:00', '6:30--22:00', 1);
INSERT INTO `line` VALUES (5, '长沙7路公交线路', 25, 201, 225, 2, '6:00--22:00', '6:30--22:00', 3);
INSERT INTO `line` VALUES (6, '长沙8路公交线路', 36, 226, 262, 2, '6:00--22:00', '6:30--22:00', 2);
INSERT INTO `line` VALUES (7, '长沙9路公交线路', 24, 301, 324, 2, '6:00--22:00', '6:30--22:00', 1);
INSERT INTO `line` VALUES (8, '长沙11路公交线路', 23, 325, 347, 2, '6:00--22:00', '6:30--22:00', 2);
INSERT INTO `line` VALUES (9, '长沙12路', 16, 401, 416, 2, '6:00--22:00', '6:30--22:00', 1);
INSERT INTO `line` VALUES (10, '长沙15路', 28, 417, 444, 2, '6:20--22:30', '6:30--21:30', 2);
INSERT INTO `line` VALUES (11, '长沙16路公交线路', 16, 501, 516, 2, '6:00-22:00', '6:00-22:00', 3);
INSERT INTO `line` VALUES (12, '长沙17路公交线路', 30, 517, 546, 2, '6:00-22:00', '6:00-22:00', 2);
INSERT INTO `line` VALUES (13, '长沙18路', 33, 601, 634, 2, '6:00--22:00', '6:30--22:00', 2);
INSERT INTO `line` VALUES (14, '长沙18区间东线', 11, 635, 646, 2, '6:00--22:00', '6:30--22:00', 3);
INSERT INTO `line` VALUES (15, '18区间西线公交线路', 13, 701, 713, 2, '6:00--22:00', '6:30--22:00', 2);
INSERT INTO `line` VALUES (16, '长沙19路', 33, 714, 744, 2, '6:00--22:00', '6:30--22:00', 3);
INSERT INTO `line` VALUES (17, '长沙63快线公交线路', 29, 801, 829, 2, '6:00--22:00', '6:30--22:00', 2);
INSERT INTO `line` VALUES (18, '长沙20路公交线路', 29, 830, 858, 2, '6:00--22:00', '6:30--22:00', 3);
INSERT INTO `line` VALUES (19, '长沙19路公交车', 32, 901, 932, 2, '6:00-22:00', '6:00-22:00', 2);
INSERT INTO `line` VALUES (20, '长沙66路', 40, 1001, 1040, 2, '6:00--22:00', '6:30--22:00', 3);

-- ----------------------------
-- Table structure for sitebyline
-- ----------------------------
DROP TABLE IF EXISTS `sitebyline`;
CREATE TABLE `sitebyline`  (
  `siteByLineId` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增,主键',
  `lineId` int(11) NOT NULL COMMENT '线路id',
  `siteOrder` int(11) NOT NULL COMMENT '站点顺序',
  `siteId` int(11) NOT NULL COMMENT '站点id',
  PRIMARY KEY (`siteByLineId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1041 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sitebyline
-- ----------------------------
INSERT INTO `sitebyline` VALUES (1, 1, 1, 1);
INSERT INTO `sitebyline` VALUES (2, 1, 2, 2);
INSERT INTO `sitebyline` VALUES (3, 1, 3, 3);
INSERT INTO `sitebyline` VALUES (4, 1, 4, 4);
INSERT INTO `sitebyline` VALUES (5, 1, 5, 5);
INSERT INTO `sitebyline` VALUES (6, 1, 6, 6);
INSERT INTO `sitebyline` VALUES (7, 1, 7, 7);
INSERT INTO `sitebyline` VALUES (8, 1, 8, 8);
INSERT INTO `sitebyline` VALUES (9, 1, 9, 9);
INSERT INTO `sitebyline` VALUES (10, 1, 10, 10);
INSERT INTO `sitebyline` VALUES (11, 1, 11, 11);
INSERT INTO `sitebyline` VALUES (12, 1, 12, 12);
INSERT INTO `sitebyline` VALUES (13, 1, 13, 13);
INSERT INTO `sitebyline` VALUES (14, 1, 14, 14);
INSERT INTO `sitebyline` VALUES (15, 1, 15, 15);
INSERT INTO `sitebyline` VALUES (16, 1, 16, 16);
INSERT INTO `sitebyline` VALUES (17, 1, 17, 17);
INSERT INTO `sitebyline` VALUES (18, 1, 18, 18);
INSERT INTO `sitebyline` VALUES (19, 1, 19, 19);
INSERT INTO `sitebyline` VALUES (20, 1, 20, 20);
INSERT INTO `sitebyline` VALUES (21, 2, 1, 21);
INSERT INTO `sitebyline` VALUES (22, 2, 2, 22);
INSERT INTO `sitebyline` VALUES (23, 2, 3, 23);
INSERT INTO `sitebyline` VALUES (24, 2, 4, 24);
INSERT INTO `sitebyline` VALUES (25, 2, 5, 25);
INSERT INTO `sitebyline` VALUES (26, 2, 6, 26);
INSERT INTO `sitebyline` VALUES (27, 2, 7, 27);
INSERT INTO `sitebyline` VALUES (28, 2, 8, 28);
INSERT INTO `sitebyline` VALUES (29, 2, 9, 29);
INSERT INTO `sitebyline` VALUES (30, 2, 10, 30);
INSERT INTO `sitebyline` VALUES (31, 2, 11, 31);
INSERT INTO `sitebyline` VALUES (32, 2, 12, 32);
INSERT INTO `sitebyline` VALUES (33, 2, 13, 33);
INSERT INTO `sitebyline` VALUES (34, 2, 14, 34);
INSERT INTO `sitebyline` VALUES (35, 2, 15, 35);
INSERT INTO `sitebyline` VALUES (36, 2, 16, 36);
INSERT INTO `sitebyline` VALUES (37, 2, 17, 37);
INSERT INTO `sitebyline` VALUES (38, 2, 18, 38);
INSERT INTO `sitebyline` VALUES (39, 2, 19, 39);
INSERT INTO `sitebyline` VALUES (40, 2, 20, 40);
INSERT INTO `sitebyline` VALUES (41, 2, 21, 41);
INSERT INTO `sitebyline` VALUES (42, 2, 22, 42);
INSERT INTO `sitebyline` VALUES (43, 2, 23, 43);
INSERT INTO `sitebyline` VALUES (44, 2, 24, 44);
INSERT INTO `sitebyline` VALUES (45, 2, 25, 45);
INSERT INTO `sitebyline` VALUES (46, 2, 26, 46);
INSERT INTO `sitebyline` VALUES (47, 2, 27, 47);
INSERT INTO `sitebyline` VALUES (48, 2, 28, 48);
INSERT INTO `sitebyline` VALUES (49, 2, 29, 49);
INSERT INTO `sitebyline` VALUES (50, 2, 30, 50);
INSERT INTO `sitebyline` VALUES (51, 2, 31, 51);
INSERT INTO `sitebyline` VALUES (52, 2, 32, 52);
INSERT INTO `sitebyline` VALUES (53, 2, 33, 53);
INSERT INTO `sitebyline` VALUES (54, 2, 34, 54);
INSERT INTO `sitebyline` VALUES (55, 2, 35, 55);
INSERT INTO `sitebyline` VALUES (56, 2, 36, 56);
INSERT INTO `sitebyline` VALUES (101, 3, 1, 101);
INSERT INTO `sitebyline` VALUES (102, 3, 2, 102);
INSERT INTO `sitebyline` VALUES (103, 3, 3, 103);
INSERT INTO `sitebyline` VALUES (104, 3, 4, 104);
INSERT INTO `sitebyline` VALUES (105, 3, 5, 105);
INSERT INTO `sitebyline` VALUES (106, 3, 6, 106);
INSERT INTO `sitebyline` VALUES (107, 3, 7, 107);
INSERT INTO `sitebyline` VALUES (108, 3, 8, 108);
INSERT INTO `sitebyline` VALUES (109, 3, 9, 109);
INSERT INTO `sitebyline` VALUES (110, 3, 10, 110);
INSERT INTO `sitebyline` VALUES (111, 3, 11, 111);
INSERT INTO `sitebyline` VALUES (112, 3, 12, 112);
INSERT INTO `sitebyline` VALUES (113, 3, 13, 113);
INSERT INTO `sitebyline` VALUES (114, 3, 14, 114);
INSERT INTO `sitebyline` VALUES (115, 3, 15, 115);
INSERT INTO `sitebyline` VALUES (116, 3, 16, 116);
INSERT INTO `sitebyline` VALUES (117, 3, 17, 117);
INSERT INTO `sitebyline` VALUES (118, 3, 18, 118);
INSERT INTO `sitebyline` VALUES (119, 3, 19, 119);
INSERT INTO `sitebyline` VALUES (120, 3, 20, 120);
INSERT INTO `sitebyline` VALUES (121, 3, 21, 121);
INSERT INTO `sitebyline` VALUES (122, 3, 22, 122);
INSERT INTO `sitebyline` VALUES (123, 4, 1, 123);
INSERT INTO `sitebyline` VALUES (124, 4, 2, 124);
INSERT INTO `sitebyline` VALUES (125, 4, 3, 125);
INSERT INTO `sitebyline` VALUES (126, 4, 4, 126);
INSERT INTO `sitebyline` VALUES (127, 4, 5, 127);
INSERT INTO `sitebyline` VALUES (128, 4, 6, 128);
INSERT INTO `sitebyline` VALUES (129, 4, 7, 129);
INSERT INTO `sitebyline` VALUES (130, 4, 8, 130);
INSERT INTO `sitebyline` VALUES (131, 4, 9, 131);
INSERT INTO `sitebyline` VALUES (132, 4, 10, 132);
INSERT INTO `sitebyline` VALUES (133, 4, 11, 133);
INSERT INTO `sitebyline` VALUES (134, 4, 12, 134);
INSERT INTO `sitebyline` VALUES (135, 4, 13, 135);
INSERT INTO `sitebyline` VALUES (136, 4, 14, 136);
INSERT INTO `sitebyline` VALUES (137, 4, 15, 137);
INSERT INTO `sitebyline` VALUES (138, 4, 16, 138);
INSERT INTO `sitebyline` VALUES (139, 4, 17, 139);
INSERT INTO `sitebyline` VALUES (140, 4, 18, 140);
INSERT INTO `sitebyline` VALUES (141, 4, 19, 141);
INSERT INTO `sitebyline` VALUES (142, 4, 20, 142);
INSERT INTO `sitebyline` VALUES (143, 4, 21, 143);
INSERT INTO `sitebyline` VALUES (144, 4, 22, 144);
INSERT INTO `sitebyline` VALUES (145, 4, 23, 145);
INSERT INTO `sitebyline` VALUES (146, 4, 24, 146);
INSERT INTO `sitebyline` VALUES (147, 4, 25, 147);
INSERT INTO `sitebyline` VALUES (148, 4, 26, 148);
INSERT INTO `sitebyline` VALUES (149, 4, 27, 149);
INSERT INTO `sitebyline` VALUES (150, 4, 28, 150);
INSERT INTO `sitebyline` VALUES (151, 4, 29, 151);
INSERT INTO `sitebyline` VALUES (152, 4, 30, 152);
INSERT INTO `sitebyline` VALUES (153, 4, 31, 153);
INSERT INTO `sitebyline` VALUES (154, 4, 32, 154);
INSERT INTO `sitebyline` VALUES (201, 5, 1, 201);
INSERT INTO `sitebyline` VALUES (202, 5, 2, 202);
INSERT INTO `sitebyline` VALUES (203, 5, 3, 203);
INSERT INTO `sitebyline` VALUES (204, 5, 4, 204);
INSERT INTO `sitebyline` VALUES (205, 5, 5, 205);
INSERT INTO `sitebyline` VALUES (206, 5, 6, 206);
INSERT INTO `sitebyline` VALUES (207, 5, 7, 207);
INSERT INTO `sitebyline` VALUES (208, 5, 8, 208);
INSERT INTO `sitebyline` VALUES (209, 5, 9, 209);
INSERT INTO `sitebyline` VALUES (210, 5, 10, 210);
INSERT INTO `sitebyline` VALUES (211, 5, 11, 211);
INSERT INTO `sitebyline` VALUES (212, 5, 12, 212);
INSERT INTO `sitebyline` VALUES (213, 5, 13, 213);
INSERT INTO `sitebyline` VALUES (214, 5, 14, 214);
INSERT INTO `sitebyline` VALUES (215, 5, 15, 215);
INSERT INTO `sitebyline` VALUES (216, 5, 16, 216);
INSERT INTO `sitebyline` VALUES (217, 5, 17, 217);
INSERT INTO `sitebyline` VALUES (218, 5, 18, 218);
INSERT INTO `sitebyline` VALUES (219, 5, 19, 219);
INSERT INTO `sitebyline` VALUES (220, 5, 20, 220);
INSERT INTO `sitebyline` VALUES (221, 5, 21, 221);
INSERT INTO `sitebyline` VALUES (222, 5, 22, 222);
INSERT INTO `sitebyline` VALUES (223, 5, 23, 223);
INSERT INTO `sitebyline` VALUES (224, 5, 24, 224);
INSERT INTO `sitebyline` VALUES (225, 5, 25, 225);
INSERT INTO `sitebyline` VALUES (226, 6, 1, 226);
INSERT INTO `sitebyline` VALUES (227, 6, 2, 227);
INSERT INTO `sitebyline` VALUES (228, 6, 3, 228);
INSERT INTO `sitebyline` VALUES (229, 6, 4, 229);
INSERT INTO `sitebyline` VALUES (230, 6, 5, 230);
INSERT INTO `sitebyline` VALUES (231, 6, 6, 231);
INSERT INTO `sitebyline` VALUES (232, 6, 7, 232);
INSERT INTO `sitebyline` VALUES (233, 6, 8, 233);
INSERT INTO `sitebyline` VALUES (234, 6, 9, 234);
INSERT INTO `sitebyline` VALUES (235, 6, 10, 235);
INSERT INTO `sitebyline` VALUES (236, 6, 11, 236);
INSERT INTO `sitebyline` VALUES (237, 6, 12, 237);
INSERT INTO `sitebyline` VALUES (238, 6, 13, 238);
INSERT INTO `sitebyline` VALUES (239, 6, 14, 239);
INSERT INTO `sitebyline` VALUES (240, 6, 15, 240);
INSERT INTO `sitebyline` VALUES (241, 6, 16, 241);
INSERT INTO `sitebyline` VALUES (242, 6, 17, 242);
INSERT INTO `sitebyline` VALUES (243, 6, 18, 243);
INSERT INTO `sitebyline` VALUES (244, 6, 19, 244);
INSERT INTO `sitebyline` VALUES (245, 6, 20, 245);
INSERT INTO `sitebyline` VALUES (246, 6, 21, 246);
INSERT INTO `sitebyline` VALUES (247, 6, 22, 247);
INSERT INTO `sitebyline` VALUES (248, 6, 23, 248);
INSERT INTO `sitebyline` VALUES (249, 6, 24, 249);
INSERT INTO `sitebyline` VALUES (250, 6, 25, 250);
INSERT INTO `sitebyline` VALUES (251, 6, 26, 251);
INSERT INTO `sitebyline` VALUES (252, 6, 27, 252);
INSERT INTO `sitebyline` VALUES (253, 6, 28, 253);
INSERT INTO `sitebyline` VALUES (254, 6, 29, 254);
INSERT INTO `sitebyline` VALUES (255, 6, 30, 255);
INSERT INTO `sitebyline` VALUES (256, 6, 31, 256);
INSERT INTO `sitebyline` VALUES (257, 6, 32, 257);
INSERT INTO `sitebyline` VALUES (258, 6, 33, 258);
INSERT INTO `sitebyline` VALUES (259, 6, 34, 259);
INSERT INTO `sitebyline` VALUES (260, 6, 35, 260);
INSERT INTO `sitebyline` VALUES (261, 6, 36, 261);
INSERT INTO `sitebyline` VALUES (301, 7, 1, 301);
INSERT INTO `sitebyline` VALUES (302, 7, 2, 302);
INSERT INTO `sitebyline` VALUES (303, 7, 3, 303);
INSERT INTO `sitebyline` VALUES (304, 7, 4, 304);
INSERT INTO `sitebyline` VALUES (305, 7, 5, 305);
INSERT INTO `sitebyline` VALUES (306, 7, 6, 306);
INSERT INTO `sitebyline` VALUES (307, 7, 7, 307);
INSERT INTO `sitebyline` VALUES (308, 7, 8, 308);
INSERT INTO `sitebyline` VALUES (309, 7, 9, 309);
INSERT INTO `sitebyline` VALUES (310, 7, 10, 310);
INSERT INTO `sitebyline` VALUES (311, 7, 11, 311);
INSERT INTO `sitebyline` VALUES (312, 7, 12, 312);
INSERT INTO `sitebyline` VALUES (313, 7, 13, 313);
INSERT INTO `sitebyline` VALUES (314, 7, 14, 314);
INSERT INTO `sitebyline` VALUES (315, 7, 15, 315);
INSERT INTO `sitebyline` VALUES (316, 7, 16, 316);
INSERT INTO `sitebyline` VALUES (317, 7, 17, 317);
INSERT INTO `sitebyline` VALUES (318, 7, 18, 318);
INSERT INTO `sitebyline` VALUES (319, 7, 19, 319);
INSERT INTO `sitebyline` VALUES (320, 7, 20, 320);
INSERT INTO `sitebyline` VALUES (321, 7, 21, 321);
INSERT INTO `sitebyline` VALUES (322, 7, 22, 322);
INSERT INTO `sitebyline` VALUES (323, 7, 23, 323);
INSERT INTO `sitebyline` VALUES (324, 7, 24, 324);
INSERT INTO `sitebyline` VALUES (325, 8, 1, 325);
INSERT INTO `sitebyline` VALUES (326, 8, 2, 326);
INSERT INTO `sitebyline` VALUES (327, 8, 3, 327);
INSERT INTO `sitebyline` VALUES (328, 8, 4, 328);
INSERT INTO `sitebyline` VALUES (329, 8, 5, 329);
INSERT INTO `sitebyline` VALUES (330, 8, 6, 330);
INSERT INTO `sitebyline` VALUES (331, 8, 7, 331);
INSERT INTO `sitebyline` VALUES (332, 8, 8, 332);
INSERT INTO `sitebyline` VALUES (333, 8, 9, 333);
INSERT INTO `sitebyline` VALUES (334, 8, 10, 334);
INSERT INTO `sitebyline` VALUES (335, 8, 11, 335);
INSERT INTO `sitebyline` VALUES (336, 8, 12, 336);
INSERT INTO `sitebyline` VALUES (337, 8, 13, 337);
INSERT INTO `sitebyline` VALUES (338, 8, 14, 338);
INSERT INTO `sitebyline` VALUES (339, 8, 15, 339);
INSERT INTO `sitebyline` VALUES (340, 8, 16, 340);
INSERT INTO `sitebyline` VALUES (341, 8, 17, 341);
INSERT INTO `sitebyline` VALUES (342, 8, 18, 342);
INSERT INTO `sitebyline` VALUES (343, 8, 19, 343);
INSERT INTO `sitebyline` VALUES (344, 8, 20, 344);
INSERT INTO `sitebyline` VALUES (345, 8, 21, 345);
INSERT INTO `sitebyline` VALUES (346, 8, 22, 346);
INSERT INTO `sitebyline` VALUES (347, 8, 23, 347);
INSERT INTO `sitebyline` VALUES (401, 9, 1, 401);
INSERT INTO `sitebyline` VALUES (402, 9, 2, 402);
INSERT INTO `sitebyline` VALUES (403, 9, 3, 403);
INSERT INTO `sitebyline` VALUES (404, 9, 4, 404);
INSERT INTO `sitebyline` VALUES (405, 9, 5, 405);
INSERT INTO `sitebyline` VALUES (406, 9, 6, 406);
INSERT INTO `sitebyline` VALUES (407, 9, 7, 407);
INSERT INTO `sitebyline` VALUES (408, 9, 8, 408);
INSERT INTO `sitebyline` VALUES (409, 9, 9, 409);
INSERT INTO `sitebyline` VALUES (410, 9, 10, 410);
INSERT INTO `sitebyline` VALUES (411, 9, 11, 411);
INSERT INTO `sitebyline` VALUES (412, 9, 12, 412);
INSERT INTO `sitebyline` VALUES (413, 9, 13, 413);
INSERT INTO `sitebyline` VALUES (414, 9, 14, 414);
INSERT INTO `sitebyline` VALUES (415, 9, 15, 415);
INSERT INTO `sitebyline` VALUES (416, 9, 16, 416);
INSERT INTO `sitebyline` VALUES (417, 10, 1, 417);
INSERT INTO `sitebyline` VALUES (418, 10, 2, 418);
INSERT INTO `sitebyline` VALUES (419, 10, 3, 419);
INSERT INTO `sitebyline` VALUES (420, 10, 4, 420);
INSERT INTO `sitebyline` VALUES (421, 10, 5, 421);
INSERT INTO `sitebyline` VALUES (422, 10, 6, 422);
INSERT INTO `sitebyline` VALUES (423, 10, 7, 423);
INSERT INTO `sitebyline` VALUES (424, 10, 8, 424);
INSERT INTO `sitebyline` VALUES (425, 10, 9, 425);
INSERT INTO `sitebyline` VALUES (426, 10, 10, 426);
INSERT INTO `sitebyline` VALUES (427, 10, 11, 427);
INSERT INTO `sitebyline` VALUES (428, 10, 12, 428);
INSERT INTO `sitebyline` VALUES (429, 10, 13, 429);
INSERT INTO `sitebyline` VALUES (430, 10, 14, 430);
INSERT INTO `sitebyline` VALUES (431, 10, 15, 431);
INSERT INTO `sitebyline` VALUES (432, 10, 16, 432);
INSERT INTO `sitebyline` VALUES (433, 10, 17, 433);
INSERT INTO `sitebyline` VALUES (434, 10, 18, 434);
INSERT INTO `sitebyline` VALUES (435, 10, 19, 435);
INSERT INTO `sitebyline` VALUES (436, 10, 20, 436);
INSERT INTO `sitebyline` VALUES (437, 10, 21, 437);
INSERT INTO `sitebyline` VALUES (438, 10, 22, 438);
INSERT INTO `sitebyline` VALUES (439, 10, 23, 439);
INSERT INTO `sitebyline` VALUES (440, 10, 24, 440);
INSERT INTO `sitebyline` VALUES (441, 10, 25, 441);
INSERT INTO `sitebyline` VALUES (442, 10, 26, 442);
INSERT INTO `sitebyline` VALUES (443, 10, 27, 443);
INSERT INTO `sitebyline` VALUES (444, 10, 28, 444);
INSERT INTO `sitebyline` VALUES (501, 11, 1, 501);
INSERT INTO `sitebyline` VALUES (502, 11, 2, 502);
INSERT INTO `sitebyline` VALUES (503, 11, 3, 503);
INSERT INTO `sitebyline` VALUES (504, 11, 4, 504);
INSERT INTO `sitebyline` VALUES (505, 11, 5, 505);
INSERT INTO `sitebyline` VALUES (506, 11, 6, 506);
INSERT INTO `sitebyline` VALUES (507, 11, 7, 507);
INSERT INTO `sitebyline` VALUES (508, 11, 8, 508);
INSERT INTO `sitebyline` VALUES (509, 11, 9, 509);
INSERT INTO `sitebyline` VALUES (510, 11, 10, 510);
INSERT INTO `sitebyline` VALUES (511, 11, 11, 511);
INSERT INTO `sitebyline` VALUES (512, 11, 12, 512);
INSERT INTO `sitebyline` VALUES (513, 11, 13, 513);
INSERT INTO `sitebyline` VALUES (514, 11, 14, 514);
INSERT INTO `sitebyline` VALUES (515, 11, 15, 515);
INSERT INTO `sitebyline` VALUES (516, 11, 16, 516);
INSERT INTO `sitebyline` VALUES (517, 12, 1, 517);
INSERT INTO `sitebyline` VALUES (518, 12, 2, 518);
INSERT INTO `sitebyline` VALUES (519, 12, 3, 519);
INSERT INTO `sitebyline` VALUES (520, 12, 4, 520);
INSERT INTO `sitebyline` VALUES (521, 12, 5, 521);
INSERT INTO `sitebyline` VALUES (522, 12, 6, 522);
INSERT INTO `sitebyline` VALUES (523, 12, 7, 523);
INSERT INTO `sitebyline` VALUES (524, 12, 8, 524);
INSERT INTO `sitebyline` VALUES (525, 12, 9, 525);
INSERT INTO `sitebyline` VALUES (526, 12, 10, 526);
INSERT INTO `sitebyline` VALUES (527, 12, 11, 527);
INSERT INTO `sitebyline` VALUES (528, 12, 12, 528);
INSERT INTO `sitebyline` VALUES (529, 12, 13, 529);
INSERT INTO `sitebyline` VALUES (530, 12, 14, 530);
INSERT INTO `sitebyline` VALUES (531, 12, 15, 531);
INSERT INTO `sitebyline` VALUES (532, 12, 16, 532);
INSERT INTO `sitebyline` VALUES (533, 12, 17, 533);
INSERT INTO `sitebyline` VALUES (534, 12, 18, 534);
INSERT INTO `sitebyline` VALUES (535, 12, 19, 535);
INSERT INTO `sitebyline` VALUES (536, 12, 20, 536);
INSERT INTO `sitebyline` VALUES (537, 12, 21, 537);
INSERT INTO `sitebyline` VALUES (538, 12, 22, 538);
INSERT INTO `sitebyline` VALUES (539, 12, 23, 539);
INSERT INTO `sitebyline` VALUES (540, 12, 24, 540);
INSERT INTO `sitebyline` VALUES (541, 12, 25, 541);
INSERT INTO `sitebyline` VALUES (542, 12, 26, 542);
INSERT INTO `sitebyline` VALUES (543, 12, 27, 543);
INSERT INTO `sitebyline` VALUES (544, 12, 28, 544);
INSERT INTO `sitebyline` VALUES (545, 12, 29, 545);
INSERT INTO `sitebyline` VALUES (546, 12, 30, 546);
INSERT INTO `sitebyline` VALUES (601, 13, 1, 601);
INSERT INTO `sitebyline` VALUES (602, 13, 2, 602);
INSERT INTO `sitebyline` VALUES (603, 13, 3, 603);
INSERT INTO `sitebyline` VALUES (604, 13, 4, 604);
INSERT INTO `sitebyline` VALUES (605, 13, 5, 605);
INSERT INTO `sitebyline` VALUES (606, 13, 6, 606);
INSERT INTO `sitebyline` VALUES (607, 13, 7, 607);
INSERT INTO `sitebyline` VALUES (608, 13, 8, 608);
INSERT INTO `sitebyline` VALUES (609, 13, 9, 609);
INSERT INTO `sitebyline` VALUES (610, 13, 10, 610);
INSERT INTO `sitebyline` VALUES (611, 13, 11, 611);
INSERT INTO `sitebyline` VALUES (612, 13, 12, 612);
INSERT INTO `sitebyline` VALUES (613, 13, 13, 613);
INSERT INTO `sitebyline` VALUES (614, 13, 14, 614);
INSERT INTO `sitebyline` VALUES (615, 13, 15, 615);
INSERT INTO `sitebyline` VALUES (616, 13, 16, 616);
INSERT INTO `sitebyline` VALUES (617, 13, 17, 617);
INSERT INTO `sitebyline` VALUES (618, 13, 18, 618);
INSERT INTO `sitebyline` VALUES (619, 13, 19, 619);
INSERT INTO `sitebyline` VALUES (620, 13, 20, 620);
INSERT INTO `sitebyline` VALUES (621, 13, 21, 621);
INSERT INTO `sitebyline` VALUES (622, 13, 22, 622);
INSERT INTO `sitebyline` VALUES (623, 13, 23, 623);
INSERT INTO `sitebyline` VALUES (624, 13, 24, 624);
INSERT INTO `sitebyline` VALUES (625, 13, 25, 625);
INSERT INTO `sitebyline` VALUES (626, 13, 26, 626);
INSERT INTO `sitebyline` VALUES (627, 13, 27, 627);
INSERT INTO `sitebyline` VALUES (628, 13, 28, 628);
INSERT INTO `sitebyline` VALUES (629, 13, 29, 629);
INSERT INTO `sitebyline` VALUES (630, 13, 30, 630);
INSERT INTO `sitebyline` VALUES (631, 13, 31, 631);
INSERT INTO `sitebyline` VALUES (632, 13, 32, 632);
INSERT INTO `sitebyline` VALUES (633, 13, 33, 633);
INSERT INTO `sitebyline` VALUES (634, 13, 34, 634);
INSERT INTO `sitebyline` VALUES (635, 14, 1, 635);
INSERT INTO `sitebyline` VALUES (636, 14, 2, 636);
INSERT INTO `sitebyline` VALUES (637, 14, 3, 637);
INSERT INTO `sitebyline` VALUES (638, 14, 4, 638);
INSERT INTO `sitebyline` VALUES (639, 14, 5, 639);
INSERT INTO `sitebyline` VALUES (640, 14, 6, 640);
INSERT INTO `sitebyline` VALUES (641, 14, 7, 641);
INSERT INTO `sitebyline` VALUES (642, 14, 8, 642);
INSERT INTO `sitebyline` VALUES (643, 14, 9, 643);
INSERT INTO `sitebyline` VALUES (644, 14, 10, 644);
INSERT INTO `sitebyline` VALUES (645, 14, 11, 645);
INSERT INTO `sitebyline` VALUES (646, 14, 12, 646);
INSERT INTO `sitebyline` VALUES (701, 15, 1, 701);
INSERT INTO `sitebyline` VALUES (702, 15, 2, 702);
INSERT INTO `sitebyline` VALUES (703, 15, 3, 703);
INSERT INTO `sitebyline` VALUES (704, 15, 4, 704);
INSERT INTO `sitebyline` VALUES (705, 15, 5, 705);
INSERT INTO `sitebyline` VALUES (706, 15, 6, 706);
INSERT INTO `sitebyline` VALUES (707, 15, 7, 707);
INSERT INTO `sitebyline` VALUES (708, 15, 8, 708);
INSERT INTO `sitebyline` VALUES (709, 15, 9, 709);
INSERT INTO `sitebyline` VALUES (710, 15, 10, 710);
INSERT INTO `sitebyline` VALUES (711, 15, 11, 711);
INSERT INTO `sitebyline` VALUES (712, 15, 12, 712);
INSERT INTO `sitebyline` VALUES (713, 15, 13, 713);
INSERT INTO `sitebyline` VALUES (714, 16, 1, 714);
INSERT INTO `sitebyline` VALUES (715, 16, 2, 715);
INSERT INTO `sitebyline` VALUES (716, 16, 3, 716);
INSERT INTO `sitebyline` VALUES (717, 16, 4, 717);
INSERT INTO `sitebyline` VALUES (718, 16, 5, 718);
INSERT INTO `sitebyline` VALUES (719, 16, 6, 719);
INSERT INTO `sitebyline` VALUES (720, 16, 7, 720);
INSERT INTO `sitebyline` VALUES (721, 16, 8, 721);
INSERT INTO `sitebyline` VALUES (722, 16, 9, 722);
INSERT INTO `sitebyline` VALUES (723, 16, 10, 723);
INSERT INTO `sitebyline` VALUES (724, 16, 11, 724);
INSERT INTO `sitebyline` VALUES (725, 16, 12, 725);
INSERT INTO `sitebyline` VALUES (726, 16, 13, 726);
INSERT INTO `sitebyline` VALUES (727, 16, 14, 727);
INSERT INTO `sitebyline` VALUES (728, 16, 15, 728);
INSERT INTO `sitebyline` VALUES (729, 16, 16, 729);
INSERT INTO `sitebyline` VALUES (730, 16, 17, 730);
INSERT INTO `sitebyline` VALUES (731, 16, 18, 731);
INSERT INTO `sitebyline` VALUES (732, 16, 19, 732);
INSERT INTO `sitebyline` VALUES (733, 16, 20, 733);
INSERT INTO `sitebyline` VALUES (734, 16, 21, 734);
INSERT INTO `sitebyline` VALUES (735, 16, 22, 735);
INSERT INTO `sitebyline` VALUES (736, 16, 23, 736);
INSERT INTO `sitebyline` VALUES (737, 16, 24, 737);
INSERT INTO `sitebyline` VALUES (738, 16, 25, 738);
INSERT INTO `sitebyline` VALUES (739, 16, 26, 739);
INSERT INTO `sitebyline` VALUES (740, 16, 27, 740);
INSERT INTO `sitebyline` VALUES (741, 16, 28, 741);
INSERT INTO `sitebyline` VALUES (742, 16, 29, 742);
INSERT INTO `sitebyline` VALUES (743, 16, 30, 743);
INSERT INTO `sitebyline` VALUES (744, 16, 31, 744);
INSERT INTO `sitebyline` VALUES (801, 17, 1, 801);
INSERT INTO `sitebyline` VALUES (802, 17, 2, 802);
INSERT INTO `sitebyline` VALUES (803, 17, 3, 803);
INSERT INTO `sitebyline` VALUES (804, 17, 4, 804);
INSERT INTO `sitebyline` VALUES (805, 17, 5, 805);
INSERT INTO `sitebyline` VALUES (806, 17, 6, 806);
INSERT INTO `sitebyline` VALUES (807, 17, 7, 807);
INSERT INTO `sitebyline` VALUES (808, 17, 8, 808);
INSERT INTO `sitebyline` VALUES (809, 17, 9, 809);
INSERT INTO `sitebyline` VALUES (810, 17, 10, 810);
INSERT INTO `sitebyline` VALUES (811, 17, 11, 811);
INSERT INTO `sitebyline` VALUES (812, 17, 12, 812);
INSERT INTO `sitebyline` VALUES (813, 17, 13, 813);
INSERT INTO `sitebyline` VALUES (814, 17, 14, 814);
INSERT INTO `sitebyline` VALUES (815, 17, 15, 815);
INSERT INTO `sitebyline` VALUES (816, 17, 16, 816);
INSERT INTO `sitebyline` VALUES (817, 17, 17, 817);
INSERT INTO `sitebyline` VALUES (818, 17, 18, 818);
INSERT INTO `sitebyline` VALUES (819, 17, 19, 819);
INSERT INTO `sitebyline` VALUES (820, 17, 20, 820);
INSERT INTO `sitebyline` VALUES (821, 17, 21, 821);
INSERT INTO `sitebyline` VALUES (822, 17, 22, 822);
INSERT INTO `sitebyline` VALUES (823, 17, 23, 823);
INSERT INTO `sitebyline` VALUES (824, 17, 24, 824);
INSERT INTO `sitebyline` VALUES (825, 17, 25, 825);
INSERT INTO `sitebyline` VALUES (826, 17, 26, 826);
INSERT INTO `sitebyline` VALUES (827, 17, 27, 827);
INSERT INTO `sitebyline` VALUES (828, 17, 28, 828);
INSERT INTO `sitebyline` VALUES (829, 17, 29, 829);
INSERT INTO `sitebyline` VALUES (830, 18, 1, 830);
INSERT INTO `sitebyline` VALUES (831, 18, 2, 831);
INSERT INTO `sitebyline` VALUES (832, 18, 3, 832);
INSERT INTO `sitebyline` VALUES (833, 18, 4, 833);
INSERT INTO `sitebyline` VALUES (834, 18, 5, 834);
INSERT INTO `sitebyline` VALUES (835, 18, 6, 835);
INSERT INTO `sitebyline` VALUES (836, 18, 7, 836);
INSERT INTO `sitebyline` VALUES (837, 18, 8, 837);
INSERT INTO `sitebyline` VALUES (838, 18, 9, 838);
INSERT INTO `sitebyline` VALUES (839, 18, 10, 839);
INSERT INTO `sitebyline` VALUES (840, 18, 11, 840);
INSERT INTO `sitebyline` VALUES (841, 18, 12, 841);
INSERT INTO `sitebyline` VALUES (842, 18, 13, 842);
INSERT INTO `sitebyline` VALUES (843, 18, 14, 843);
INSERT INTO `sitebyline` VALUES (844, 18, 15, 844);
INSERT INTO `sitebyline` VALUES (845, 18, 16, 845);
INSERT INTO `sitebyline` VALUES (846, 18, 17, 846);
INSERT INTO `sitebyline` VALUES (847, 18, 18, 847);
INSERT INTO `sitebyline` VALUES (848, 18, 19, 848);
INSERT INTO `sitebyline` VALUES (849, 18, 20, 849);
INSERT INTO `sitebyline` VALUES (850, 18, 21, 850);
INSERT INTO `sitebyline` VALUES (851, 18, 22, 851);
INSERT INTO `sitebyline` VALUES (852, 18, 23, 852);
INSERT INTO `sitebyline` VALUES (853, 18, 24, 853);
INSERT INTO `sitebyline` VALUES (854, 18, 25, 854);
INSERT INTO `sitebyline` VALUES (855, 18, 26, 855);
INSERT INTO `sitebyline` VALUES (856, 18, 27, 856);
INSERT INTO `sitebyline` VALUES (857, 18, 28, 857);
INSERT INTO `sitebyline` VALUES (858, 18, 29, 858);
INSERT INTO `sitebyline` VALUES (901, 19, 1, 901);
INSERT INTO `sitebyline` VALUES (902, 19, 2, 902);
INSERT INTO `sitebyline` VALUES (903, 19, 3, 903);
INSERT INTO `sitebyline` VALUES (904, 19, 4, 904);
INSERT INTO `sitebyline` VALUES (905, 19, 5, 905);
INSERT INTO `sitebyline` VALUES (906, 19, 6, 906);
INSERT INTO `sitebyline` VALUES (907, 19, 7, 907);
INSERT INTO `sitebyline` VALUES (908, 19, 8, 908);
INSERT INTO `sitebyline` VALUES (909, 19, 9, 909);
INSERT INTO `sitebyline` VALUES (910, 19, 10, 910);
INSERT INTO `sitebyline` VALUES (911, 19, 11, 911);
INSERT INTO `sitebyline` VALUES (912, 19, 12, 912);
INSERT INTO `sitebyline` VALUES (913, 19, 13, 913);
INSERT INTO `sitebyline` VALUES (914, 19, 14, 914);
INSERT INTO `sitebyline` VALUES (915, 19, 15, 915);
INSERT INTO `sitebyline` VALUES (916, 19, 16, 916);
INSERT INTO `sitebyline` VALUES (917, 19, 17, 917);
INSERT INTO `sitebyline` VALUES (918, 19, 18, 918);
INSERT INTO `sitebyline` VALUES (919, 19, 19, 919);
INSERT INTO `sitebyline` VALUES (920, 19, 20, 920);
INSERT INTO `sitebyline` VALUES (921, 19, 21, 921);
INSERT INTO `sitebyline` VALUES (922, 19, 22, 922);
INSERT INTO `sitebyline` VALUES (923, 19, 23, 923);
INSERT INTO `sitebyline` VALUES (924, 19, 24, 924);
INSERT INTO `sitebyline` VALUES (925, 19, 25, 925);
INSERT INTO `sitebyline` VALUES (926, 19, 26, 926);
INSERT INTO `sitebyline` VALUES (927, 19, 27, 927);
INSERT INTO `sitebyline` VALUES (928, 19, 28, 928);
INSERT INTO `sitebyline` VALUES (929, 19, 29, 929);
INSERT INTO `sitebyline` VALUES (930, 19, 30, 930);
INSERT INTO `sitebyline` VALUES (931, 19, 31, 931);
INSERT INTO `sitebyline` VALUES (932, 19, 32, 932);
INSERT INTO `sitebyline` VALUES (1001, 20, 1, 1001);
INSERT INTO `sitebyline` VALUES (1002, 20, 2, 1002);
INSERT INTO `sitebyline` VALUES (1003, 20, 3, 1003);
INSERT INTO `sitebyline` VALUES (1004, 20, 4, 1004);
INSERT INTO `sitebyline` VALUES (1005, 20, 5, 1005);
INSERT INTO `sitebyline` VALUES (1006, 20, 6, 1006);
INSERT INTO `sitebyline` VALUES (1007, 20, 7, 1007);
INSERT INTO `sitebyline` VALUES (1008, 20, 8, 1008);
INSERT INTO `sitebyline` VALUES (1009, 20, 9, 1009);
INSERT INTO `sitebyline` VALUES (1010, 20, 10, 1010);
INSERT INTO `sitebyline` VALUES (1011, 20, 11, 1011);
INSERT INTO `sitebyline` VALUES (1012, 20, 12, 1012);
INSERT INTO `sitebyline` VALUES (1013, 20, 13, 1013);
INSERT INTO `sitebyline` VALUES (1014, 20, 14, 1014);
INSERT INTO `sitebyline` VALUES (1015, 20, 15, 1015);
INSERT INTO `sitebyline` VALUES (1016, 20, 16, 1016);
INSERT INTO `sitebyline` VALUES (1017, 20, 17, 1017);
INSERT INTO `sitebyline` VALUES (1018, 20, 18, 1018);
INSERT INTO `sitebyline` VALUES (1019, 20, 19, 1019);
INSERT INTO `sitebyline` VALUES (1020, 20, 20, 1020);
INSERT INTO `sitebyline` VALUES (1021, 20, 21, 1021);
INSERT INTO `sitebyline` VALUES (1022, 20, 22, 1022);
INSERT INTO `sitebyline` VALUES (1023, 20, 23, 1023);
INSERT INTO `sitebyline` VALUES (1024, 20, 24, 1024);
INSERT INTO `sitebyline` VALUES (1025, 20, 25, 1025);
INSERT INTO `sitebyline` VALUES (1026, 20, 26, 1026);
INSERT INTO `sitebyline` VALUES (1027, 20, 27, 1027);
INSERT INTO `sitebyline` VALUES (1028, 20, 28, 1028);
INSERT INTO `sitebyline` VALUES (1029, 20, 29, 1029);
INSERT INTO `sitebyline` VALUES (1030, 20, 30, 1030);
INSERT INTO `sitebyline` VALUES (1031, 20, 31, 1031);
INSERT INTO `sitebyline` VALUES (1032, 20, 32, 1032);
INSERT INTO `sitebyline` VALUES (1033, 20, 33, 1033);
INSERT INTO `sitebyline` VALUES (1034, 20, 34, 1034);
INSERT INTO `sitebyline` VALUES (1035, 20, 35, 1035);
INSERT INTO `sitebyline` VALUES (1036, 20, 36, 1036);
INSERT INTO `sitebyline` VALUES (1037, 20, 37, 1037);
INSERT INTO `sitebyline` VALUES (1038, 20, 38, 1038);
INSERT INTO `sitebyline` VALUES (1039, 20, 39, 1039);
INSERT INTO `sitebyline` VALUES (1040, 20, 40, 1040);

-- ----------------------------
-- Table structure for sitetable
-- ----------------------------
DROP TABLE IF EXISTS `sitetable`;
CREATE TABLE `sitetable`  (
  `siteId` int(11) NOT NULL COMMENT '自增，主键',
  `siteName` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '站点名',
  `isElectronic` int(11) NOT NULL COMMENT '1:为电子站牌\r\n0：非电子站牌\r\n是否是电子站牌',
  `isStationyard` int(11) NOT NULL COMMENT '1:为站场\r\n0：非站场\r\n是否为站场',
  PRIMARY KEY (`siteId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sitetable
-- ----------------------------
INSERT INTO `sitetable` VALUES (1, '长沙火车站', 1, 1);
INSERT INTO `sitetable` VALUES (2, '蓉园路口', 1, 0);
INSERT INTO `sitetable` VALUES (3, '省公安厅', 1, 0);
INSERT INTO `sitetable` VALUES (4, '袁家岭', 0, 0);
INSERT INTO `sitetable` VALUES (5, '省军区', 1, 0);
INSERT INTO `sitetable` VALUES (6, '清水塘军区医', 1, 0);
INSERT INTO `sitetable` VALUES (7, '小吴门', 0, 0);
INSERT INTO `sitetable` VALUES (8, '中山路', 1, 0);
INSERT INTO `sitetable` VALUES (9, '先锋厅', 1, 1);
INSERT INTO `sitetable` VALUES (10, '长沙轮渡', 0, 0);
INSERT INTO `sitetable` VALUES (11, '橘子洲大桥东', 1, 0);
INSERT INTO `sitetable` VALUES (12, '坡子街', 0, 0);
INSERT INTO `sitetable` VALUES (13, '西湖桥', 0, 0);
INSERT INTO `sitetable` VALUES (14, '楚湘街', 1, 0);
INSERT INTO `sitetable` VALUES (15, '灵官渡', 1, 0);
INSERT INTO `sitetable` VALUES (16, '第一师范', 1, 0);
INSERT INTO `sitetable` VALUES (17, '大春桥', 0, 0);
INSERT INTO `sitetable` VALUES (18, '杏花园', 1, 0);
INSERT INTO `sitetable` VALUES (19, '碧沙街', 1, 0);
INSERT INTO `sitetable` VALUES (20, '古堆山', 1, 1);
INSERT INTO `sitetable` VALUES (21, '桔园小区', 1, 1);
INSERT INTO `sitetable` VALUES (22, '华侨村', 1, 1);
INSERT INTO `sitetable` VALUES (23, '桔园立交桥东(桔园路)', 0, 0);
INSERT INTO `sitetable` VALUES (24, '桔园立交桥北', 0, 0);
INSERT INTO `sitetable` VALUES (25, '安贞医院(雨花亭北)', 0, 0);
INSERT INTO `sitetable` VALUES (26, '砂子塘', 0, 0);
INSERT INTO `sitetable` VALUES (27, '省中医附一院(东塘南)', 0, 0);
INSERT INTO `sitetable` VALUES (28, '东塘西', 0, 0);
INSERT INTO `sitetable` VALUES (29, '雅礼中学', 0, 0);
INSERT INTO `sitetable` VALUES (30, '侯家塘', 0, 0);
INSERT INTO `sitetable` VALUES (31, '长沙市三医院(仰天湖)', 1, 0);
INSERT INTO `sitetable` VALUES (32, '白沙路口', 1, 0);
INSERT INTO `sitetable` VALUES (33, '沙河街', 1, 0);
INSERT INTO `sitetable` VALUES (34, '南门口', 1, 0);
INSERT INTO `sitetable` VALUES (35, '天心阁西门', 1, 0);
INSERT INTO `sitetable` VALUES (36, '競才修业学校(柑子园西)', 1, 0);
INSERT INTO `sitetable` VALUES (37, '司门口', 1, 0);
INSERT INTO `sitetable` VALUES (38, '贾谊故居', 1, 0);
INSERT INTO `sitetable` VALUES (39, '解放西路口', 1, 0);
INSERT INTO `sitetable` VALUES (40, '长沙轮渡', 1, 0);
INSERT INTO `sitetable` VALUES (41, '先锋厅(中山亭)', 1, 1);
INSERT INTO `sitetable` VALUES (42, '中山亭', 1, 0);
INSERT INTO `sitetable` VALUES (43, '省中医院(巡道街)', 1, 0);
INSERT INTO `sitetable` VALUES (44, '省中医院(营盘街)', 1, 0);
INSERT INTO `sitetable` VALUES (45, '省妇幼', 1, 0);
INSERT INTO `sitetable` VALUES (46, '湖南日报', 0, 0);
INSERT INTO `sitetable` VALUES (47, '湘雅路口', 1, 0);
INSERT INTO `sitetable` VALUES (48, '唐家巷', 1, 0);
INSERT INTO `sitetable` VALUES (49, '芙蓉路口', 0, 0);
INSERT INTO `sitetable` VALUES (50, '华夏', 0, 0);
INSERT INTO `sitetable` VALUES (51, '华夏路口', 1, 0);
INSERT INTO `sitetable` VALUES (52, '长雅中学', 1, 0);
INSERT INTO `sitetable` VALUES (53, '黄兴北路秋月路口', 1, 0);
INSERT INTO `sitetable` VALUES (54, '紫凤路', 0, 0);
INSERT INTO `sitetable` VALUES (55, '北辰时代广场', 0, 0);
INSERT INTO `sitetable` VALUES (56, '北辰三角洲', 1, 1);
INSERT INTO `sitetable` VALUES (101, '劳动广场', 1, 0);
INSERT INTO `sitetable` VALUES (102, '白沙路口', 1, 0);
INSERT INTO `sitetable` VALUES (103, '长沙市三医院', 1, 0);
INSERT INTO `sitetable` VALUES (104, '侯家塘', 1, 1);
INSERT INTO `sitetable` VALUES (105, '侯家塘南', 1, 0);
INSERT INTO `sitetable` VALUES (106, '黄土岭', 1, 0);
INSERT INTO `sitetable` VALUES (107, '省第二人民医院', 1, 0);
INSERT INTO `sitetable` VALUES (108, '涂家冲南', 1, 0);
INSERT INTO `sitetable` VALUES (109, '长沙理工大学', 1, 0);
INSERT INTO `sitetable` VALUES (110, '金盆岭', 0, 0);
INSERT INTO `sitetable` VALUES (111, '公用客车厂', 0, 1);
INSERT INTO `sitetable` VALUES (112, '省红十字妇幼', 0, 1);
INSERT INTO `sitetable` VALUES (113, '猴子石路口', 0, 0);
INSERT INTO `sitetable` VALUES (114, '百姓市场', 0, 0);
INSERT INTO `sitetable` VALUES (115, '新开铺', 0, 0);
INSERT INTO `sitetable` VALUES (116, '1003厂', 0, 0);
INSERT INTO `sitetable` VALUES (117, '新开铺路友谊', 1, 0);
INSERT INTO `sitetable` VALUES (118, '豹子岭', 1, 0);
INSERT INTO `sitetable` VALUES (119, '二豹子岭', 1, 0);
INSERT INTO `sitetable` VALUES (120, '湘府路大桥西', 1, 0);
INSERT INTO `sitetable` VALUES (121, '阳湖湿地公园', 1, 0);
INSERT INTO `sitetable` VALUES (122, '洋湖景园', 1, 1);
INSERT INTO `sitetable` VALUES (123, '赤岗冲', 1, 1);
INSERT INTO `sitetable` VALUES (124, '东塘东', 1, 0);
INSERT INTO `sitetable` VALUES (125, '东塘北', 1, 0);
INSERT INTO `sitetable` VALUES (126, '曹家坡', 0, 0);
INSERT INTO `sitetable` VALUES (127, '长沙市妇幼保', 0, 0);
INSERT INTO `sitetable` VALUES (128, '湖南省图书馆', 0, 0);
INSERT INTO `sitetable` VALUES (129, '袁家岭南', 0, 0);
INSERT INTO `sitetable` VALUES (130, '韭菜岭', 0, 0);
INSERT INTO `sitetable` VALUES (131, '牛耳教育南阳', 0, 0);
INSERT INTO `sitetable` VALUES (132, '华图教育太平', 0, 0);
INSERT INTO `sitetable` VALUES (133, '高叶塘', 0, 0);
INSERT INTO `sitetable` VALUES (134, '省人防办东', 0, 0);
INSERT INTO `sitetable` VALUES (135, '省人防办', 0, 0);
INSERT INTO `sitetable` VALUES (136, '忘麓桥', 0, 0);
INSERT INTO `sitetable` VALUES (137, '麓山名苑', 1, 1);
INSERT INTO `sitetable` VALUES (138, '省结核病医院', 1, 1);
INSERT INTO `sitetable` VALUES (139, '教师村', 1, 0);
INSERT INTO `sitetable` VALUES (140, '白鹤咀', 1, 1);
INSERT INTO `sitetable` VALUES (141, '咸嘉新村', 0, 1);
INSERT INTO `sitetable` VALUES (142, '咸嘉新村西', 1, 0);
INSERT INTO `sitetable` VALUES (143, '湘麓山庄', 0, 0);
INSERT INTO `sitetable` VALUES (144, '金星路口', 0, 0);
INSERT INTO `sitetable` VALUES (145, '市政府', 0, 0);
INSERT INTO `sitetable` VALUES (146, '市委', 0, 0);
INSERT INTO `sitetable` VALUES (147, '观沙路', 1, 0);
INSERT INTO `sitetable` VALUES (148, '含光路口', 1, 0);
INSERT INTO `sitetable` VALUES (149, '茶山路口', 1, 0);
INSERT INTO `sitetable` VALUES (150, '长郡中学新学校', 1, 1);
INSERT INTO `sitetable` VALUES (201, '长沙火车站', 1, 1);
INSERT INTO `sitetable` VALUES (202, '曙光路口', 1, 0);
INSERT INTO `sitetable` VALUES (203, '袁家岭南', 1, 0);
INSERT INTO `sitetable` VALUES (204, '湖南省图书馆', 1, 0);
INSERT INTO `sitetable` VALUES (205, '窑岭南', 1, 0);
INSERT INTO `sitetable` VALUES (206, '长沙市妇幼保健', 1, 0);
INSERT INTO `sitetable` VALUES (207, '曹家坡', 1, 0);
INSERT INTO `sitetable` VALUES (208, '东塘北', 1, 0);
INSERT INTO `sitetable` VALUES (209, '省中医附一院', 1, 0);
INSERT INTO `sitetable` VALUES (210, '砂子塘', 1, 0);
INSERT INTO `sitetable` VALUES (211, '安贞医院(雨花亭北)', 1, 0);
INSERT INTO `sitetable` VALUES (212, '桔园立交桥北', 1, 0);
INSERT INTO `sitetable` VALUES (213, '铁道学院', 1, 0);
INSERT INTO `sitetable` VALUES (214, '长沙市中医院', 1, 0);
INSERT INTO `sitetable` VALUES (215, '潇湘晨报', 1, 0);
INSERT INTO `sitetable` VALUES (216, '林科大', 1, 0);
INSERT INTO `sitetable` VALUES (217, '井坡子', 1, 0);
INSERT INTO `sitetable` VALUES (218, '井湾子北', 1, 0);
INSERT INTO `sitetable` VALUES (219, '井湾子南', 1, 0);
INSERT INTO `sitetable` VALUES (220, '中建五局', 1, 0);
INSERT INTO `sitetable` VALUES (221, '红星村南', 1, 0);
INSERT INTO `sitetable` VALUES (222, '高升村南', 1, 0);
INSERT INTO `sitetable` VALUES (223, '省植物园', 1, 0);
INSERT INTO `sitetable` VALUES (224, '洞井铺', 1, 0);
INSERT INTO `sitetable` VALUES (225, '汽车南站', 1, 1);
INSERT INTO `sitetable` VALUES (226, '长沙火车南站', 1, 1);
INSERT INTO `sitetable` VALUES (227, '香樟东路口', 1, 0);
INSERT INTO `sitetable` VALUES (228, '长托', 1, 0);
INSERT INTO `sitetable` VALUES (229, '圭塘', 1, 0);
INSERT INTO `sitetable` VALUES (230, '龙骧巴士公司', 1, 0);
INSERT INTO `sitetable` VALUES (231, '雨花区政府北', 1, 0);
INSERT INTO `sitetable` VALUES (232, '窑坡', 1, 0);
INSERT INTO `sitetable` VALUES (233, '师家老屋', 1, 0);
INSERT INTO `sitetable` VALUES (234, '雨花区交警队', 1, 0);
INSERT INTO `sitetable` VALUES (235, '新星小区', 1, 0);
INSERT INTO `sitetable` VALUES (236, '雨花公安分局', 1, 0);
INSERT INTO `sitetable` VALUES (237, '鼓风', 1, 0);
INSERT INTO `sitetable` VALUES (238, '树木岭', 1, 0);
INSERT INTO `sitetable` VALUES (239, '自然岭', 1, 0);
INSERT INTO `sitetable` VALUES (240, '树木岭路口', 1, 0);
INSERT INTO `sitetable` VALUES (241, '树木岭立交桥', 1, 0);
INSERT INTO `sitetable` VALUES (242, '矿通', 1, 0);
INSERT INTO `sitetable` VALUES (243, '友谊新村', 1, 0);
INSERT INTO `sitetable` VALUES (244, '狮子山东', 1, 0);
INSERT INTO `sitetable` VALUES (245, '狮子山南', 1, 0);
INSERT INTO `sitetable` VALUES (246, '红花坡', 1, 0);
INSERT INTO `sitetable` VALUES (247, '茶园坡路口', 1, 0);
INSERT INTO `sitetable` VALUES (248, '车站南路口', 1, 0);
INSERT INTO `sitetable` VALUES (249, '茶园岭', 1, 0);
INSERT INTO `sitetable` VALUES (250, '赤岗岭', 1, 0);
INSERT INTO `sitetable` VALUES (251, '赤岗冲', 1, 0);
INSERT INTO `sitetable` VALUES (252, '野坡', 1, 0);
INSERT INTO `sitetable` VALUES (253, '东塘东（长沙联通）', 1, 0);
INSERT INTO `sitetable` VALUES (254, '东塘西', 1, 0);
INSERT INTO `sitetable` VALUES (255, '雅礼中学', 1, 0);
INSERT INTO `sitetable` VALUES (256, '侯家塘', 1, 0);
INSERT INTO `sitetable` VALUES (257, '长沙市三医院', 1, 0);
INSERT INTO `sitetable` VALUES (258, '白沙路口', 1, 0);
INSERT INTO `sitetable` VALUES (259, '沙河街', 1, 0);
INSERT INTO `sitetable` VALUES (260, '南门口', 1, 0);
INSERT INTO `sitetable` VALUES (261, '长郡中学', 1, 1);
INSERT INTO `sitetable` VALUES (301, '金霞苑总站', 1, 1);
INSERT INTO `sitetable` VALUES (302, '金霞苑', 0, 0);
INSERT INTO `sitetable` VALUES (303, '汽车北站', 1, 0);
INSERT INTO `sitetable` VALUES (304, '开福区政府', 1, 0);
INSERT INTO `sitetable` VALUES (305, '马厂', 0, 0);
INSERT INTO `sitetable` VALUES (306, '新码头', 0, 0);
INSERT INTO `sitetable` VALUES (307, '陈家湖', 1, 0);
INSERT INTO `sitetable` VALUES (308, '伍家岭南', 0, 0);
INSERT INTO `sitetable` VALUES (309, '潘家坪', 1, 0);
INSERT INTO `sitetable` VALUES (310, '唐家巷', 0, 0);
INSERT INTO `sitetable` VALUES (311, '湘雅路口', 1, 0);
INSERT INTO `sitetable` VALUES (312, '湖南日报', 1, 0);
INSERT INTO `sitetable` VALUES (313, '松佳园', 1, 0);
INSERT INTO `sitetable` VALUES (314, '八一桥', 0, 0);
INSERT INTO `sitetable` VALUES (315, '芙蓉广场', 0, 0);
INSERT INTO `sitetable` VALUES (316, '省建行（浏城桥） ', 1, 0);
INSERT INTO `sitetable` VALUES (317, '识字岭（东）', 1, 0);
INSERT INTO `sitetable` VALUES (318, '地质中学', 0, 0);
INSERT INTO `sitetable` VALUES (319, '湘雅二医院', 1, 0);
INSERT INTO `sitetable` VALUES (320, '窑岭东', 1, 0);
INSERT INTO `sitetable` VALUES (321, '曙光站', 1, 0);
INSERT INTO `sitetable` VALUES (322, '人名路立交桥', 1, 0);
INSERT INTO `sitetable` VALUES (323, '人民路立交桥', 1, 0);
INSERT INTO `sitetable` VALUES (324, '长沙火车站', 1, 1);
INSERT INTO `sitetable` VALUES (325, '赤岗冲', 1, 1);
INSERT INTO `sitetable` VALUES (326, '东塘东（长沙联）', 0, 1);
INSERT INTO `sitetable` VALUES (327, '东塘西', 0, 0);
INSERT INTO `sitetable` VALUES (328, '雅礼中学', 1, 1);
INSERT INTO `sitetable` VALUES (329, '省儿童医院', 0, 0);
INSERT INTO `sitetable` VALUES (330, '红旗药号', 1, 1);
INSERT INTO `sitetable` VALUES (331, '广济桥', 1, 0);
INSERT INTO `sitetable` VALUES (332, '梓园路口', 1, 1);
INSERT INTO `sitetable` VALUES (333, '地质中学', 0, 0);
INSERT INTO `sitetable` VALUES (334, '识字岭（东）', 1, 1);
INSERT INTO `sitetable` VALUES (335, '凤凰台', 1, 0);
INSERT INTO `sitetable` VALUES (336, '中公省教育', 1, 1);
INSERT INTO `sitetable` VALUES (337, '湖南省人民医院', 1, 1);
INSERT INTO `sitetable` VALUES (338, '司门口', 1, 1);
INSERT INTO `sitetable` VALUES (339, '贾谊故居', 0, 0);
INSERT INTO `sitetable` VALUES (340, '解放西路口', 0, 1);
INSERT INTO `sitetable` VALUES (341, '长沙轮渡', 1, 0);
INSERT INTO `sitetable` VALUES (342, '朝宗街', 1, 0);
INSERT INTO `sitetable` VALUES (343, '通泰街', 0, 1);
INSERT INTO `sitetable` VALUES (344, '华盛新外滩', 1, 0);
INSERT INTO `sitetable` VALUES (345, '湘雅路西口', 0, 0);
INSERT INTO `sitetable` VALUES (346, '竹山园', 1, 0);
INSERT INTO `sitetable` VALUES (347, '开福寺西', 1, 1);
INSERT INTO `sitetable` VALUES (401, '汽车西站(河西交通枢纽过渡站)', 1, 1);
INSERT INTO `sitetable` VALUES (402, '汽车西站(北)', 1, 0);
INSERT INTO `sitetable` VALUES (403, '望城坡', 1, 0);
INSERT INTO `sitetable` VALUES (404, '湖湘中医院肿瘤', 1, 0);
INSERT INTO `sitetable` VALUES (405, '湖南财政经济', 1, 0);
INSERT INTO `sitetable` VALUES (406, '望麓桥', 1, 0);
INSERT INTO `sitetable` VALUES (407, '省人防办', 1, 0);
INSERT INTO `sitetable` VALUES (408, '省人防办东', 1, 0);
INSERT INTO `sitetable` VALUES (409, '高叶塘', 1, 0);
INSERT INTO `sitetable` VALUES (410, '荣湾镇·', 1, 0);
INSERT INTO `sitetable` VALUES (411, '华图教育（太平街口）', 1, 0);
INSERT INTO `sitetable` VALUES (412, '牛耳教育（南阳街口）', 1, 0);
INSERT INTO `sitetable` VALUES (413, '韭菜园', 1, 0);
INSERT INTO `sitetable` VALUES (414, '曙光路口', 1, 0);
INSERT INTO `sitetable` VALUES (415, '长岛路口', 1, 0);
INSERT INTO `sitetable` VALUES (416, '长沙火车站', 1, 1);
INSERT INTO `sitetable` VALUES (417, '赤岗冲(多功能坪)', 1, 1);
INSERT INTO `sitetable` VALUES (418, '东塘东(长沙联通)', 1, 0);
INSERT INTO `sitetable` VALUES (419, '省中医附一院(东塘南)', 1, 0);
INSERT INTO `sitetable` VALUES (420, '砂子塘', 1, 0);
INSERT INTO `sitetable` VALUES (421, '安贞医院(雨花亭北)', 1, 0);
INSERT INTO `sitetable` VALUES (422, '桔园立交桥北', 1, 0);
INSERT INTO `sitetable` VALUES (423, '铁道学院', 1, 0);
INSERT INTO `sitetable` VALUES (424, '长沙市中心医院', 1, 0);
INSERT INTO `sitetable` VALUES (425, '潇湘晨报', 1, 0);
INSERT INTO `sitetable` VALUES (426, '林科大', 1, 0);
INSERT INTO `sitetable` VALUES (427, '井坡子', 1, 0);
INSERT INTO `sitetable` VALUES (428, '木莲路韶山路', 1, 0);
INSERT INTO `sitetable` VALUES (429, '木莲路林大路', 1, 0);
INSERT INTO `sitetable` VALUES (430, '林大录木莲路', 1, 0);
INSERT INTO `sitetable` VALUES (431, '林大路友谊路', 1, 0);
INSERT INTO `sitetable` VALUES (432, '万芙路新韶路', 1, 0);
INSERT INTO `sitetable` VALUES (433, '万芙路正塘坡', 1, 0);
INSERT INTO `sitetable` VALUES (434, '湖南人才市场', 1, 0);
INSERT INTO `sitetable` VALUES (435, '万芙路湘府路', 1, 0);
INSERT INTO `sitetable` VALUES (436, '高家冲', 1, 0);
INSERT INTO `sitetable` VALUES (437, '万芙路杉木冲', 1, 0);
INSERT INTO `sitetable` VALUES (438, '三角塘', 1, 0);
INSERT INTO `sitetable` VALUES (439, '和平小区', 1, 0);
INSERT INTO `sitetable` VALUES (440, '万芙路中意路', 1, 0);
INSERT INTO `sitetable` VALUES (441, '中国保险学院', 1, 0);
INSERT INTO `sitetable` VALUES (442, '外贸学院', 1, 0);
INSERT INTO `sitetable` VALUES (443, '湘府中学', 1, 0);
INSERT INTO `sitetable` VALUES (444, '友阿奥特莱斯', 1, 1);
INSERT INTO `sitetable` VALUES (501, '汽车南站', 1, 1);
INSERT INTO `sitetable` VALUES (502, '洞井铺', 1, 0);
INSERT INTO `sitetable` VALUES (503, '省植物园', 1, 0);
INSERT INTO `sitetable` VALUES (504, '高升村南', 1, 0);
INSERT INTO `sitetable` VALUES (505, '莲花小区', 1, 0);
INSERT INTO `sitetable` VALUES (506, '省植物园北', 1, 0);
INSERT INTO `sitetable` VALUES (507, '唐湘电器市场', 1, 0);
INSERT INTO `sitetable` VALUES (508, '煤田地质局', 1, 0);
INSERT INTO `sitetable` VALUES (509, '喜盈门范城', 1, 0);
INSERT INTO `sitetable` VALUES (510, '窑坡', 1, 0);
INSERT INTO `sitetable` VALUES (511, '雨花区政府北', 1, 0);
INSERT INTO `sitetable` VALUES (512, '龙骧巴士公司', 1, 0);
INSERT INTO `sitetable` VALUES (513, '圭塘', 1, 0);
INSERT INTO `sitetable` VALUES (514, '长托', 1, 0);
INSERT INTO `sitetable` VALUES (515, '香樟东路口', 1, 0);
INSERT INTO `sitetable` VALUES (516, '长沙火车南站', 1, 1);
INSERT INTO `sitetable` VALUES (517, '汽车南站', 1, 1);
INSERT INTO `sitetable` VALUES (518, '洞井铺', 1, 0);
INSERT INTO `sitetable` VALUES (519, '省植物园', 1, 0);
INSERT INTO `sitetable` VALUES (520, '高升村南', 1, 0);
INSERT INTO `sitetable` VALUES (521, '高升村北', 1, 0);
INSERT INTO `sitetable` VALUES (522, '红星村南', 1, 0);
INSERT INTO `sitetable` VALUES (523, '中建五局', 1, 0);
INSERT INTO `sitetable` VALUES (524, '井湾子南', 1, 0);
INSERT INTO `sitetable` VALUES (525, '井湾子北', 1, 0);
INSERT INTO `sitetable` VALUES (526, '井坡子', 1, 0);
INSERT INTO `sitetable` VALUES (527, '林科大', 1, 0);
INSERT INTO `sitetable` VALUES (528, '潇湘晨报', 1, 0);
INSERT INTO `sitetable` VALUES (529, '长沙市中心医院', 1, 0);
INSERT INTO `sitetable` VALUES (530, '铁道学院', 1, 0);
INSERT INTO `sitetable` VALUES (531, '新开铺路口', 1, 0);
INSERT INTO `sitetable` VALUES (532, '南郊公园', 1, 0);
INSERT INTO `sitetable` VALUES (533, '阳光100国际新城', 1, 0);
INSERT INTO `sitetable` VALUES (534, '后湖路口', 1, 0);
INSERT INTO `sitetable` VALUES (535, '罗家嘴立交桥', 1, 0);
INSERT INTO `sitetable` VALUES (536, '桃园村', 1, 0);
INSERT INTO `sitetable` VALUES (537, '沙泥塘', 1, 0);
INSERT INTO `sitetable` VALUES (538, '王家湾', 1, 0);
INSERT INTO `sitetable` VALUES (539, '王家湾北', 1, 0);
INSERT INTO `sitetable` VALUES (540, '树达学院', 1, 0);
INSERT INTO `sitetable` VALUES (541, '桃花岭', 1, 0);
INSERT INTO `sitetable` VALUES (542, '瓜瓢山', 1, 0);
INSERT INTO `sitetable` VALUES (543, '丝茅坪', 1, 0);
INSERT INTO `sitetable` VALUES (544, '联络村', 1, 0);
INSERT INTO `sitetable` VALUES (545, '望城坡南', 1, 0);
INSERT INTO `sitetable` VALUES (546, '汽车西站', 1, 1);
INSERT INTO `sitetable` VALUES (601, '东方红路首末站', 1, 0);
INSERT INTO `sitetable` VALUES (602, '嘉运路谷苑路口', 0, 0);
INSERT INTO `sitetable` VALUES (603, '和馨园小区', 0, 0);
INSERT INTO `sitetable` VALUES (604, '嘉运路东方红路口', 0, 1);
INSERT INTO `sitetable` VALUES (605, '东方红安置小区', 0, 0);
INSERT INTO `sitetable` VALUES (606, '一师范', 0, 0);
INSERT INTO `sitetable` VALUES (607, '麓松路枫林路口', 0, 0);
INSERT INTO `sitetable` VALUES (608, '涉外西门', 0, 0);
INSERT INTO `sitetable` VALUES (609, '高新区工商局', 0, 0);
INSERT INTO `sitetable` VALUES (610, '涉外北门', 0, 0);
INSERT INTO `sitetable` VALUES (611, '锦和园小区北', 0, 0);
INSERT INTO `sitetable` VALUES (612, '文轩路麓云路口', 0, 0);
INSERT INTO `sitetable` VALUES (613, '文轩路平川路口', 0, 0);
INSERT INTO `sitetable` VALUES (614, '麓谷', 0, 0);
INSERT INTO `sitetable` VALUES (615, '中联重科', 0, 0);
INSERT INTO `sitetable` VALUES (616, '高新区管委会', 0, 0);
INSERT INTO `sitetable` VALUES (617, '麓枫路', 0, 0);
INSERT INTO `sitetable` VALUES (618, '省少管所', 0, 1);
INSERT INTO `sitetable` VALUES (619, '博才实验中学', 0, 0);
INSERT INTO `sitetable` VALUES (620, '麓景路口', 0, 1);
INSERT INTO `sitetable` VALUES (621, '雷锋大道口', 0, 0);
INSERT INTO `sitetable` VALUES (622, '玉兰路', 0, 0);
INSERT INTO `sitetable` VALUES (623, '汽车西站', 1, 0);
INSERT INTO `sitetable` VALUES (624, '望城坡', 0, 0);
INSERT INTO `sitetable` VALUES (625, '湖湘中医肿瘤医院', 0, 1);
INSERT INTO `sitetable` VALUES (626, '湖南财政经济学院', 0, 0);
INSERT INTO `sitetable` VALUES (627, '望麓桥', 0, 0);
INSERT INTO `sitetable` VALUES (628, '省人防办', 0, 0);
INSERT INTO `sitetable` VALUES (629, '省人防办东', 0, 0);
INSERT INTO `sitetable` VALUES (630, '高叶塘', 0, 0);
INSERT INTO `sitetable` VALUES (631, '溁湾镇', 0, 0);
INSERT INTO `sitetable` VALUES (632, '华图教育(太平街口)', 0, 0);
INSERT INTO `sitetable` VALUES (633, '牛耳教育(南阳街口)', 0, 0);
INSERT INTO `sitetable` VALUES (634, '司门口', 0, 0);
INSERT INTO `sitetable` VALUES (635, '汽车西站(河西交通枢纽过渡站)', 1, 1);
INSERT INTO `sitetable` VALUES (636, '湘仪路口', 0, 0);
INSERT INTO `sitetable` VALUES (637, '麓景路', 0, 0);
INSERT INTO `sitetable` VALUES (638, '湖南公信', 0, 1);
INSERT INTO `sitetable` VALUES (639, '桐梓坡路麓枫路口', 0, 1);
INSERT INTO `sitetable` VALUES (640, '高新区管委会', 0, 0);
INSERT INTO `sitetable` VALUES (641, '麓谷大道桐梓坡路口', 0, 0);
INSERT INTO `sitetable` VALUES (642, '青山路尖山路口', 0, 0);
INSERT INTO `sitetable` VALUES (643, '麓松路林语路口', 0, 0);
INSERT INTO `sitetable` VALUES (644, '林语路麓松路口', 0, 0);
INSERT INTO `sitetable` VALUES (645, '林语路东方红路口', 0, 0);
INSERT INTO `sitetable` VALUES (646, '东方红路首末站', 0, 1);
INSERT INTO `sitetable` VALUES (701, '汽车西站', 1, 1);
INSERT INTO `sitetable` VALUES (702, '湘仪路口', 0, 0);
INSERT INTO `sitetable` VALUES (703, '三里垅', 0, 0);
INSERT INTO `sitetable` VALUES (704, '湖南航天医院', 0, 0);
INSERT INTO `sitetable` VALUES (705, '燕联村', 0, 0);
INSERT INTO `sitetable` VALUES (706, '平川路口', 0, 0);
INSERT INTO `sitetable` VALUES (707, '麓云路口', 0, 0);
INSERT INTO `sitetable` VALUES (708, '锦和园小区', 0, 0);
INSERT INTO `sitetable` VALUES (709, '麓云路文轩路口', 0, 0);
INSERT INTO `sitetable` VALUES (710, '梦洁麓谷工业园', 0, 0);
INSERT INTO `sitetable` VALUES (711, '谷苑路', 0, 0);
INSERT INTO `sitetable` VALUES (712, '湘电水泵', 0, 0);
INSERT INTO `sitetable` VALUES (713, '东方红路首末站', 0, 1);
INSERT INTO `sitetable` VALUES (714, '赤岗冲(多功能坪)', 1, 1);
INSERT INTO `sitetable` VALUES (715, '赤岗冲', 0, 0);
INSERT INTO `sitetable` VALUES (716, '赤岗岭', 0, 0);
INSERT INTO `sitetable` VALUES (717, '茶园坡', 0, 0);
INSERT INTO `sitetable` VALUES (718, '车站南路口', 0, 0);
INSERT INTO `sitetable` VALUES (719, '红花坡', 0, 0);
INSERT INTO `sitetable` VALUES (720, '狮子山南', 0, 0);
INSERT INTO `sitetable` VALUES (721, '狮子山东', 0, 0);
INSERT INTO `sitetable` VALUES (722, '高桥大市场南', 0, 0);
INSERT INTO `sitetable` VALUES (723, '马王堆路朝晖路口', 0, 0);
INSERT INTO `sitetable` VALUES (724, '马王堆路人民路口', 0, 0);
INSERT INTO `sitetable` VALUES (725, '樟木坝', 0, 0);
INSERT INTO `sitetable` VALUES (726, '荷花路口[马王堆路]', 0, 0);
INSERT INTO `sitetable` VALUES (727, '惠泽园', 0, 0);
INSERT INTO `sitetable` VALUES (728, '马王堆市场', 0, 0);
INSERT INTO `sitetable` VALUES (729, '马王堆路凌霄路口', 0, 0);
INSERT INTO `sitetable` VALUES (730, '田家炳中学', 0, 0);
INSERT INTO `sitetable` VALUES (731, '龙柏路口', 0, 0);
INSERT INTO `sitetable` VALUES (732, '省检察院', 0, 0);
INSERT INTO `sitetable` VALUES (733, '芙蓉苑', 0, 0);
INSERT INTO `sitetable` VALUES (734, '火炬路西', 0, 0);
INSERT INTO `sitetable` VALUES (735, '烈士公园东门', 0, 0);
INSERT INTO `sitetable` VALUES (736, '兑泽街', 0, 0);
INSERT INTO `sitetable` VALUES (737, '跃进湖', 0, 0);
INSERT INTO `sitetable` VALUES (738, '丝茅冲北', 0, 0);
INSERT INTO `sitetable` VALUES (739, '喻家冲', 0, 0);
INSERT INTO `sitetable` VALUES (740, '国防科大', 0, 0);
INSERT INTO `sitetable` VALUES (741, '九尾冲', 0, 0);
INSERT INTO `sitetable` VALUES (742, '陡岭', 0, 0);
INSERT INTO `sitetable` VALUES (743, '陡岭路双拥路口', 0, 0);
INSERT INTO `sitetable` VALUES (744, '栖凤路', 0, 1);
INSERT INTO `sitetable` VALUES (801, '汽车西站(河西交通枢纽过渡站)', 1, 1);
INSERT INTO `sitetable` VALUES (802, '望城坡南', 1, 1);
INSERT INTO `sitetable` VALUES (803, '联络村', 0, 0);
INSERT INTO `sitetable` VALUES (804, '王家湾', 0, 0);
INSERT INTO `sitetable` VALUES (805, '沙泥塘', 1, 1);
INSERT INTO `sitetable` VALUES (806, '桃园村', 0, 0);
INSERT INTO `sitetable` VALUES (807, '阳光100国际新城', 0, 0);
INSERT INTO `sitetable` VALUES (808, '南郊公园', 0, 0);
INSERT INTO `sitetable` VALUES (809, '新开铺路口', 0, 0);
INSERT INTO `sitetable` VALUES (810, '丁家垅', 0, 0);
INSERT INTO `sitetable` VALUES (811, '中联重科海外公司(浦沅南)', 0, 0);
INSERT INTO `sitetable` VALUES (812, '竹塘路', 0, 0);
INSERT INTO `sitetable` VALUES (813, '铁道学院', 0, 0);
INSERT INTO `sitetable` VALUES (814, '长沙市中心医院', 0, 0);
INSERT INTO `sitetable` VALUES (815, '香樟路', 0, 0);
INSERT INTO `sitetable` VALUES (816, '樟树屋', 0, 0);
INSERT INTO `sitetable` VALUES (817, '油子塘', 1, 1);
INSERT INTO `sitetable` VALUES (818, '洞井路口', 0, 0);
INSERT INTO `sitetable` VALUES (819, '北冲水库', 0, 0);
INSERT INTO `sitetable` VALUES (820, '一字墙', 1, 1);
INSERT INTO `sitetable` VALUES (821, '藕塘坡', 0, 0);
INSERT INTO `sitetable` VALUES (822, '师家老屋', 0, 0);
INSERT INTO `sitetable` VALUES (823, '窑坡', 0, 0);
INSERT INTO `sitetable` VALUES (824, '雨花区政府北', 0, 0);
INSERT INTO `sitetable` VALUES (825, '龙骧巴士公司', 0, 0);
INSERT INTO `sitetable` VALUES (826, '圭塘', 0, 0);
INSERT INTO `sitetable` VALUES (827, '长托', 0, 0);
INSERT INTO `sitetable` VALUES (828, '香樟东路口', 0, 0);
INSERT INTO `sitetable` VALUES (829, '长沙火车南站', 1, 1);
INSERT INTO `sitetable` VALUES (830, '湘府路大桥东公交首末站', 1, 1);
INSERT INTO `sitetable` VALUES (831, '黑石铺火车站', 0, 0);
INSERT INTO `sitetable` VALUES (832, '黑石铺', 1, 1);
INSERT INTO `sitetable` VALUES (833, '黑石铺中南大市场', 0, 0);
INSERT INTO `sitetable` VALUES (834, '黑石村', 0, 0);
INSERT INTO `sitetable` VALUES (835, '黑石铺路新开铺路口', 1, 1);
INSERT INTO `sitetable` VALUES (836, '黑石铺路书香路口', 0, 0);
INSERT INTO `sitetable` VALUES (837, '九峰公园', 0, 0);
INSERT INTO `sitetable` VALUES (838, '九峰小区北门', 0, 0);
INSERT INTO `sitetable` VALUES (839, '桂花坪(新姚南路)', 0, 0);
INSERT INTO `sitetable` VALUES (840, '时代阳光大道芙蓉路口', 0, 0);
INSERT INTO `sitetable` VALUES (841, '时代阳光大道刘家冲路口', 0, 0);
INSERT INTO `sitetable` VALUES (842, '时代阳光大道石碑路口', 0, 0);
INSERT INTO `sitetable` VALUES (843, '时代阳光大道万芙路口', 0, 0);
INSERT INTO `sitetable` VALUES (844, '时代阳光大道高升路口', 0, 0);
INSERT INTO `sitetable` VALUES (845, '时代阳光大道韶山路口', 0, 0);
INSERT INTO `sitetable` VALUES (846, '汽车南站(北)', 0, 0);
INSERT INTO `sitetable` VALUES (847, '公交技校', 1, 1);
INSERT INTO `sitetable` VALUES (848, '全洲药业', 0, 0);
INSERT INTO `sitetable` VALUES (849, '省质监局', 0, 0);
INSERT INTO `sitetable` VALUES (850, '坪坝塘', 1, 1);
INSERT INTO `sitetable` VALUES (851, '万家丽路口', 0, 0);
INSERT INTO `sitetable` VALUES (852, '庙下屋', 0, 0);
INSERT INTO `sitetable` VALUES (853, '宏聚·地中海', 0, 0);
INSERT INTO `sitetable` VALUES (854, '高速出口', 0, 0);
INSERT INTO `sitetable` VALUES (855, '京珠跨线桥', 0, 0);
INSERT INTO `sitetable` VALUES (856, '杨罗公路口', 0, 0);
INSERT INTO `sitetable` VALUES (857, '同升湖路南', 0, 0);
INSERT INTO `sitetable` VALUES (858, '同升湖', 1, 1);
INSERT INTO `sitetable` VALUES (901, '赤岗冲', 1, 1);
INSERT INTO `sitetable` VALUES (902, '赤岗玲', 1, 1);
INSERT INTO `sitetable` VALUES (903, '茶园坡', 0, 0);
INSERT INTO `sitetable` VALUES (904, '车站南路口', 1, 0);
INSERT INTO `sitetable` VALUES (905, '茶园坡路口', 1, 1);
INSERT INTO `sitetable` VALUES (906, '红花坡', 0, 1);
INSERT INTO `sitetable` VALUES (907, '狮子山南', 1, 1);
INSERT INTO `sitetable` VALUES (908, '狮子山东', 0, 1);
INSERT INTO `sitetable` VALUES (909, '高桥大市场南', 1, 0);
INSERT INTO `sitetable` VALUES (910, '马王堆路朝晖', 1, 1);
INSERT INTO `sitetable` VALUES (911, '马王堆路人民', 1, 1);
INSERT INTO `sitetable` VALUES (912, '樟木坝', 1, 1);
INSERT INTO `sitetable` VALUES (913, '荷花路口', 0, 1);
INSERT INTO `sitetable` VALUES (914, '芙蓉中学', 1, 0);
INSERT INTO `sitetable` VALUES (915, '惠泽园', 1, 1);
INSERT INTO `sitetable` VALUES (916, '马王堆市场', 0, 1);
INSERT INTO `sitetable` VALUES (917, '马王堆路凌霄', 1, 1);
INSERT INTO `sitetable` VALUES (918, '田家炳中学', 0, 1);
INSERT INTO `sitetable` VALUES (919, '龙柏路口', 1, 1);
INSERT INTO `sitetable` VALUES (920, '省检察院', 0, 0);
INSERT INTO `sitetable` VALUES (921, '芙蓉苑', 1, 1);
INSERT INTO `sitetable` VALUES (922, '火炬路西', 1, 1);
INSERT INTO `sitetable` VALUES (923, '烈士公园东门', 1, 0);
INSERT INTO `sitetable` VALUES (924, '兑泽街', 1, 1);
INSERT INTO `sitetable` VALUES (925, '跃进湖', 1, 0);
INSERT INTO `sitetable` VALUES (926, '丝茅出北', 0, 1);
INSERT INTO `sitetable` VALUES (927, '喻家冲', 1, 1);
INSERT INTO `sitetable` VALUES (928, '国防科大', 1, 0);
INSERT INTO `sitetable` VALUES (929, '九尾冲', 0, 1);
INSERT INTO `sitetable` VALUES (930, '陡岭', 0, 1);
INSERT INTO `sitetable` VALUES (931, '陡岭路双拥路', 0, 0);
INSERT INTO `sitetable` VALUES (932, '栖凤路', 1, 1);
INSERT INTO `sitetable` VALUES (1001, '汽车西站(河西交通枢纽过渡站)', 0, 1);
INSERT INTO `sitetable` VALUES (1002, '玉兰路', 1, 0);
INSERT INTO `sitetable` VALUES (1003, '雷锋大道口', 0, 0);
INSERT INTO `sitetable` VALUES (1004, '玉兰路口', 0, 1);
INSERT INTO `sitetable` VALUES (1005, '商学院', 0, 0);
INSERT INTO `sitetable` VALUES (1006, '咸嘉花园', 0, 0);
INSERT INTO `sitetable` VALUES (1007, '咸嘉新村', 1, 0);
INSERT INTO `sitetable` VALUES (1008, '白鸽咀', 0, 0);
INSERT INTO `sitetable` VALUES (1009, '省肿瘤医院', 0, 0);
INSERT INTO `sitetable` VALUES (1010, '湘雅医学院', 0, 0);
INSERT INTO `sitetable` VALUES (1011, '湘雅三医院', 0, 0);
INSERT INTO `sitetable` VALUES (1012, '桐梓坡', 0, 0);
INSERT INTO `sitetable` VALUES (1013, '六沟垅', 0, 1);
INSERT INTO `sitetable` VALUES (1014, '中联重科科技园(银盆岭)', 0, 0);
INSERT INTO `sitetable` VALUES (1015, '银盆岭大桥西', 0, 0);
INSERT INTO `sitetable` VALUES (1016, '国防科大', 0, 0);
INSERT INTO `sitetable` VALUES (1017, '喻家冲', 0, 0);
INSERT INTO `sitetable` VALUES (1018, '百花园路口', 0, 0);
INSERT INTO `sitetable` VALUES (1019, '德雅路口', 0, 0);
INSERT INTO `sitetable` VALUES (1020, '省教育厅', 1, 0);
INSERT INTO `sitetable` VALUES (1021, '南湖大市场东', 0, 0);
INSERT INTO `sitetable` VALUES (1022, '凌霄路', 0, 0);
INSERT INTO `sitetable` VALUES (1023, '纬二路', 0, 0);
INSERT INTO `sitetable` VALUES (1024, '商贸城', 0, 0);
INSERT INTO `sitetable` VALUES (1025, '远大路口', 0, 0);
INSERT INTO `sitetable` VALUES (1026, '万家丽广场', 1, 1);
INSERT INTO `sitetable` VALUES (1027, '芙蓉区政府(西)', 0, 0);
INSERT INTO `sitetable` VALUES (1028, '朝晖路口(五一驾校)', 0, 0);
INSERT INTO `sitetable` VALUES (1029, '高桥大市场东', 0, 0);
INSERT INTO `sitetable` VALUES (1030, '长沙大道口', 0, 0);
INSERT INTO `sitetable` VALUES (1031, '劳动东路口', 1, 0);
INSERT INTO `sitetable` VALUES (1032, '曲塘路口', 0, 0);
INSERT INTO `sitetable` VALUES (1033, '湖南联通', 0, 0);
INSERT INTO `sitetable` VALUES (1034, '窑坡', 0, 0);
INSERT INTO `sitetable` VALUES (1035, '雨花区政府北', 0, 0);
INSERT INTO `sitetable` VALUES (1036, '龙骧巴士公司', 1, 0);
INSERT INTO `sitetable` VALUES (1037, '圭塘', 0, 0);
INSERT INTO `sitetable` VALUES (1038, '长托', 0, 0);
INSERT INTO `sitetable` VALUES (1039, '香樟东路口', 0, 0);
INSERT INTO `sitetable` VALUES (1040, '长沙火车南站', 0, 1);
INSERT INTO `sitetable` VALUES (1041, '长沙火车站11', 1, 1);

-- ----------------------------
-- Table structure for userinfo
-- ----------------------------
DROP TABLE IF EXISTS `userinfo`;
CREATE TABLE `userinfo`  (
  `userinfoId` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键，自增',
  `tel` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '手机号码',
  `userinfoName` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '用户名',
  `passWord` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '密码',
  PRIMARY KEY (`userinfoId`) USING BTREE,
  UNIQUE INDEX `tel`(`tel`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 25 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of userinfo
-- ----------------------------
INSERT INTO `userinfo` VALUES (1, '333', '333', '222');
INSERT INTO `userinfo` VALUES (2, '444', '444', '444');
INSERT INTO `userinfo` VALUES (3, 'testadmin', '13545874521', '456');
INSERT INTO `userinfo` VALUES (4, '1364587142', 'testsuper', '123');
INSERT INTO `userinfo` VALUES (5, '111', '111', '456');
INSERT INTO `userinfo` VALUES (9, '222', '111', '123');
INSERT INTO `userinfo` VALUES (10, '33', '111', '123');
INSERT INTO `userinfo` VALUES (11, '555', '33', '33');
INSERT INTO `userinfo` VALUES (12, '666', '666', '666');
INSERT INTO `userinfo` VALUES (13, '888', '888', '888');
INSERT INTO `userinfo` VALUES (14, '1314232383', 'limin', '123');
INSERT INTO `userinfo` VALUES (17, '1314232', 'lin', '123');
INSERT INTO `userinfo` VALUES (23, '18814562131', 'testadmin', '666');
INSERT INTO `userinfo` VALUES (24, '123', 'hhy', '123');

SET FOREIGN_KEY_CHECKS = 1;
